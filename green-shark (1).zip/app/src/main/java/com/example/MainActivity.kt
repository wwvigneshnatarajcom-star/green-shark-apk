package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.example.overlay.OverlayStateManager
import com.example.ui.ActivationModal
import com.example.ui.ActiveModal
import com.example.ui.AddGameDialog
import com.example.ui.HomeScreen
import com.example.ui.MainViewModel
import com.example.ui.PointerCaptureArenaDialog
import com.example.ui.SettingsDialog
import com.example.ui.SplashIntroScreen
import com.example.ui.theme.GreenSharkTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        viewModel.onResumeRefresh()
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        enableEdgeToEdge()
        requestNotificationPermissionIfNeeded()

        setContent {
            GreenSharkTheme {
                var showSplash by rememberSaveable { mutableStateOf(true) }
                val games by viewModel.games.collectAsState()
                val installedApps by viewModel.installedApps.collectAsState()
                val isLoadingApps by viewModel.isLoadingApps.collectAsState()
                val appSearchQuery by viewModel.appSearchQuery.collectAsState()
                val peripheralStatus by viewModel.peripheralStatus.collectAsState()
                val activationState by viewModel.activationState.collectAsState()
                val globalSettings by viewModel.globalSettings.collectAsState()
                val selectedProfile by viewModel.selectedProfile.collectAsState()
                val hasOverlayPermission by viewModel.hasOverlayPermission.collectAsState()
                val isOverlayRunning by viewModel.isOverlayRunning.collectAsState()
                val activeModal by viewModel.activeModal.collectAsState()
                val toastMessage by viewModel.toastMessage.collectAsState()

                LaunchedEffect(toastMessage) {
                    toastMessage?.let { msg ->
                        Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
                        viewModel.clearToast()
                    }
                }

                Crossfade(
                    targetState = showSplash,
                    animationSpec = tween(durationMillis = 280),
                    label = "splash_to_home"
                ) { isSplash ->
                    if (isSplash) {
                        SplashIntroScreen(onFinished = { showSplash = false })
                    } else {
                        HomeScreen(
                            games = games,
                            selectedGamePackage = selectedProfile.packageName,
                            selectedProfileName = selectedProfile.profileName,
                            peripheralStatus = peripheralStatus,
                            activationState = activationState,
                            onSelectGame = { game ->
                                viewModel.selectProfileForGame(game.packageName, game.label)
                            },
                            onOpenActivation = { viewModel.openModal(ActiveModal.ACTIVATION) },
                            onOpenAddGame = { viewModel.openModal(ActiveModal.ADD_GAME) },
                            onOpenSettings = { viewModel.openModal(ActiveModal.SETTINGS) },
                            onOpenPointerArena = { viewModel.openModal(ActiveModal.POINTER_CAPTURE_ARENA) },
                            onLaunchGame = { game ->
                                if (!viewModel.launchGameWithOverlay(game)) {
                                    requestOverlayPermission()
                                }
                            },
                            onConfigureGameProfile = { game ->
                                viewModel.selectProfileForGame(game.packageName, game.label)
                                viewModel.openModal(ActiveModal.SETTINGS)
                            },
                            onRemoveGame = { game -> viewModel.removeGame(game.packageName) }
                        )
                    }
                }

                when (activeModal) {
                    ActiveModal.ACTIVATION -> ActivationModal(
                        state = activationState,
                        onDismiss = { viewModel.closeModal() },
                        onStartWirelessScan = { viewModel.startWirelessDiscovery() },
                        onPairWireless = { code, port -> viewModel.pairWirelessDebugging(code, port) },
                        onOpenDeveloperOptions = { viewModel.openDeveloperOptions() },
                        onActivateShizuku = { viewModel.activateShizuku() },
                        onOpenShizuku = { viewModel.openShizukuApp() },
                        onOpenAccessibility = { viewModel.openAccessibilitySettings() },
                        onMarkPcAdbActivated = { viewModel.markPcAdbActivated() }
                    )

                    ActiveModal.ADD_GAME -> AddGameDialog(
                        installedApps = installedApps,
                        isLoading = isLoadingApps,
                        searchQuery = appSearchQuery,
                        onSearchQueryChange = { viewModel.setAppSearchQuery(it) },
                        onSelectApp = { app -> viewModel.addGame(app) },
                        onDismiss = { viewModel.closeModal() }
                    )

                    ActiveModal.SETTINGS -> SettingsDialog(
                        settings = globalSettings,
                        selectedProfile = selectedProfile,
                        games = games,
                        onUpdateSettings = { viewModel.updateGlobalSettings(it) },
                        onSelectGameProfile = { pkg, lbl -> viewModel.selectProfileForGame(pkg, lbl) },
                        onSaveProfile = { viewModel.saveSelectedProfile(it) },
                        onRenameProfile = { viewModel.renameSelectedProfile(it) },
                        onResetProfile = { viewModel.resetSelectedProfile() },
                        onExportJson = { viewModel.exportSelectedProfileJson() },
                        onImportJson = { viewModel.importProfileJson(it) },
                        onDismiss = { viewModel.closeModal() }
                    )

                    ActiveModal.POINTER_CAPTURE_ARENA -> PointerCaptureArenaDialog(
                        processor = viewModel.inputProcessor,
                        profile = selectedProfile,
                        settings = globalSettings,
                        onDismiss = { viewModel.closeModal() }
                    )

                    ActiveModal.NONE -> {}
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        OverlayStateManager.setHomeForeground(true)
        viewModel.onResumeRefresh()
    }

    override fun onPause() {
        super.onPause()
        OverlayStateManager.setHomeForeground(false)
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}
