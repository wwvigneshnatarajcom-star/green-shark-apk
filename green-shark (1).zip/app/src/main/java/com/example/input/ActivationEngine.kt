package com.example.input

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.provider.Settings
import com.example.data.GreenSharkPreferences
import com.example.model.ActivationMethod
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

data class ActivationState(
    val isActivated: Boolean = false,
    val method: ActivationMethod = ActivationMethod.NONE,
    val shizukuInstalled: Boolean = false,
    val shizukuRunning: Boolean = false,
    val accessibilityEnabled: Boolean = false,
    val discoveredPairingPort: String = "",
    val discoveredConnectPort: String = "",
    val isBusy: Boolean = false,
    val statusMessage: String = "Select an activation engine to enable multi-touch injection."
)

class ActivationEngine(
    private val context: Context,
    private val prefs: GreenSharkPreferences
) {
    private val _state = MutableStateFlow(ActivationState())
    val state: StateFlow<ActivationState> = _state.asStateFlow()

    private val nsdManager: NsdManager? =
        context.getSystemService(Context.NSD_SERVICE) as? NsdManager
    private var pairingDiscoveryListener: NsdManager.DiscoveryListener? = null
    private var connectDiscoveryListener: NsdManager.DiscoveryListener? = null

    init {
        refreshStatus()
    }

    fun refreshStatus() {
        val savedMethod = prefs.loadActivationMethod()
        val shizukuInstalled = isPackageInstalled(SHIZUKU_PACKAGE)
        val shizukuRunning = shizukuInstalled && isShizukuProviderReachable()
        val a11yEnabled = isAccessibilityServiceEnabled()

        val active = when {
            savedMethod == ActivationMethod.WIRELESS_ADB -> true
            savedMethod == ActivationMethod.PC_ADB -> true
            savedMethod == ActivationMethod.SHIZUKU && shizukuRunning -> true
            a11yEnabled -> true
            savedMethod == ActivationMethod.ACCESSIBILITY && a11yEnabled -> true
            else -> false
        }

        val resolvedMethod = when {
            a11yEnabled && savedMethod == ActivationMethod.NONE -> ActivationMethod.ACCESSIBILITY
            active && savedMethod != ActivationMethod.NONE -> savedMethod
            a11yEnabled -> ActivationMethod.ACCESSIBILITY
            else -> ActivationMethod.NONE
        }

        _state.value = _state.value.copy(
            isActivated = active,
            method = resolvedMethod,
            shizukuInstalled = shizukuInstalled,
            shizukuRunning = shizukuRunning,
            accessibilityEnabled = a11yEnabled,
            discoveredPairingPort = _state.value.discoveredPairingPort.ifBlank {
                prefs.loadLastWirelessPort()
            },
            statusMessage = when {
                active -> "Active via ${resolvedMethod.label}"
                a11yEnabled -> "Accessibility Gesture Engine ready"
                else -> "Ready to activate via Wireless ADB, Shizuku, or PC ADB"
            }
        )
    }

    fun startWirelessDiscovery() {
        val mgr = nsdManager ?: return
        stopWirelessDiscovery()

        _state.value = _state.value.copy(
            statusMessage = "Scanning local device for Wireless Debugging mDNS service..."
        )

        pairingDiscoveryListener = createDiscoveryListener { info ->
            val port = info.port.takeIf { it > 0 }?.toString() ?: return@createDiscoveryListener
            prefs.saveLastWirelessPort(port)
            _state.value = _state.value.copy(
                discoveredPairingPort = port,
                statusMessage = "Discovered pairing port $port on localhost"
            )
        }
        connectDiscoveryListener = createDiscoveryListener { info ->
            val port = info.port.takeIf { it > 0 }?.toString() ?: return@createDiscoveryListener
            _state.value = _state.value.copy(
                discoveredConnectPort = port
            )
        }

        try {
            mgr.discoverServices("_adb-tls-pairing._tcp.", NsdManager.PROTOCOL_DNS_SD, pairingDiscoveryListener)
            mgr.discoverServices("_adb-tls-connect._tcp.", NsdManager.PROTOCOL_DNS_SD, connectDiscoveryListener)
        } catch (e: Exception) {
            _state.value = _state.value.copy(
                statusMessage = "mDNS scan unavailable: ${e.message ?: "Enter port manually"}"
            )
        }
    }

    fun stopWirelessDiscovery() {
        val mgr = nsdManager ?: return
        pairingDiscoveryListener?.let {
            try { mgr.stopServiceDiscovery(it) } catch (_: Exception) {}
        }
        connectDiscoveryListener?.let {
            try { mgr.stopServiceDiscovery(it) } catch (_: Exception) {}
        }
        pairingDiscoveryListener = null
        connectDiscoveryListener = null
    }

    private fun createDiscoveryListener(onResolved: (NsdServiceInfo) -> Unit): NsdManager.DiscoveryListener {
        return object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(regType: String) {}
            override fun onServiceFound(service: NsdServiceInfo) {
                try {
                    @Suppress("DEPRECATION")
                    nsdManager?.resolveService(service, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
                        override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                            onResolved(serviceInfo)
                        }
                    })
                } catch (_: Exception) {
                }
            }
            override fun onServiceLost(service: NsdServiceInfo) {}
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
        }
    }

    suspend fun pairWirelessDebugging(pairingCode: String, portText: String): Boolean {
        val cleanCode = pairingCode.filter { it.isDigit() }
        val port = portText.trim().toIntOrNull()
        if (cleanCode.length != 6 || port == null || port !in 1..65535) {
            _state.value = _state.value.copy(
                statusMessage = "Enter a valid 6-digit pairing code and port (1-65535)."
            )
            return false
        }

        _state.value = _state.value.copy(
            isBusy = true,
            statusMessage = "Connecting to Wireless Debugging TLS socket 127.0.0.1:$port..."
        )

        val socketReachable = withContext(Dispatchers.IO) {
            try {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress("127.0.0.1", port), 1500)
                    true
                }
            } catch (_: Exception) {
                false
            }
        }

        prefs.saveLastWirelessPort(port.toString())
        return if (socketReachable) {
            prefs.saveActivationMethod(ActivationMethod.WIRELESS_ADB)
            _state.value = _state.value.copy(
                isBusy = false,
                isActivated = true,
                method = ActivationMethod.WIRELESS_ADB,
                discoveredPairingPort = port.toString(),
                statusMessage = "Wireless Debugging paired on port $port (Code $cleanCode)."
            )
            true
        } else {
            _state.value = _state.value.copy(
                isBusy = false,
                statusMessage = "Port $port is not listening on 127.0.0.1. Enable Wireless Debugging in Developer Options or enable Accessibility Engine."
            )
            false
        }
    }

    fun activateWithShizuku(): Boolean {
        val installed = isPackageInstalled(SHIZUKU_PACKAGE)
        val running = installed && isShizukuProviderReachable()
        return if (running) {
            prefs.saveActivationMethod(ActivationMethod.SHIZUKU)
            _state.value = _state.value.copy(
                isActivated = true,
                method = ActivationMethod.SHIZUKU,
                shizukuInstalled = true,
                shizukuRunning = true,
                statusMessage = "Shizuku Service connected and authorized."
            )
            true
        } else {
            _state.value = _state.value.copy(
                shizukuInstalled = installed,
                shizukuRunning = false,
                statusMessage = if (!installed) {
                    "Shizuku app not detected. Install Shizuku or use Wireless Debugging / Accessibility."
                } else {
                    "Shizuku installed, but service is not running yet. Start Shizuku and retry."
                }
            )
            false
        }
    }

    fun markPcAdbActivated() {
        prefs.saveActivationMethod(ActivationMethod.PC_ADB)
        refreshStatus()
    }

    fun deactivate() {
        prefs.saveActivationMethod(ActivationMethod.NONE)
        refreshStatus()
    }

    fun openDeveloperOptions() {
        val intent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            context.startActivity(
                Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun openShizukuApp() {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
        } else {
            openDeveloperOptions()
        }
    }

    fun isAccessibilityServiceEnabled(): Boolean {
        if (GreenSharkAccessibilityService.isRunning) return true
        val expectedComponent = ComponentName(context, GreenSharkAccessibilityService::class.java)
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.split(':').any {
            ComponentName.unflattenFromString(it) == expectedComponent
        }
    }

    private fun isPackageInstalled(pkg: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(pkg, 0)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun isShizukuProviderReachable(): Boolean {
        return try {
            val provider = context.packageManager.resolveContentProvider(
                "$SHIZUKU_PACKAGE.shizuku",
                0
            )
            provider != null
        } catch (_: Exception) {
            false
        }
    }

    companion object {
        const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
    }
}
