package com.example.input

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import java.lang.ref.WeakReference

class GreenSharkAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instanceRef = WeakReference(this)
        isRunning = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Used purely for gesture dispatch & optional key event filtering
    }

    override fun onInterrupt() {
        isRunning = false
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        instanceRef = null
    }

    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event != null && externalKeyInterceptor?.invoke(event) == true) {
            return true
        }
        return super.onKeyEvent(event)
    }

    fun dispatchTap(x: Float, y: Float, durationMs: Long = 35L) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(15L))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    fun dispatchSwipe(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long = 80L
    ) {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(16L))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    fun dispatchMultiTouch(strokes: List<StrokeSpec>) {
        if (strokes.isEmpty()) return
        val builder = GestureDescription.Builder()
        var added = 0
        val maxStrokes = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            GestureDescription.getMaxStrokeCount().coerceAtMost(10)
        } else 1

        for (spec in strokes) {
            if (added >= maxStrokes) break
            val path = Path().apply {
                moveTo(spec.startX, spec.startY)
                if (spec.endX != spec.startX || spec.endY != spec.startY) {
                    lineTo(spec.endX, spec.endY)
                }
            }
            val stroke = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && spec.willContinue) {
                GestureDescription.StrokeDescription(
                    path,
                    spec.startTimeMs,
                    spec.durationMs.coerceAtLeast(16L),
                    true
                )
            } else {
                GestureDescription.StrokeDescription(
                    path,
                    spec.startTimeMs,
                    spec.durationMs.coerceAtLeast(16L)
                )
            }
            builder.addStroke(stroke)
            added++
        }
        if (added > 0) {
            dispatchGesture(builder.build(), null, null)
        }
    }

    data class StrokeSpec(
        val startX: Float,
        val startY: Float,
        val endX: Float,
        val endY: Float,
        val startTimeMs: Long = 0L,
        val durationMs: Long = 40L,
        val willContinue: Boolean = false
    )

    companion object {
        @Volatile
        var isRunning: Boolean = false
            private set

        @Volatile
        private var instanceRef: WeakReference<GreenSharkAccessibilityService>? = null

        @Volatile
        var externalKeyInterceptor: ((KeyEvent) -> Boolean)? = null

        fun getInstance(): GreenSharkAccessibilityService? = instanceRef?.get()
    }
}
