package com.example.input

import android.view.KeyEvent
import android.view.MotionEvent
import com.example.model.ActionMode
import com.example.model.GameMappingProfile
import com.example.model.GlobalSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.hypot

data class InputRuntimeState(
    val shootingModeLocked: Boolean = false,
    val cursorXNorm: Float = 0.5f,
    val cursorYNorm: Float = 0.5f,
    val wasdVectorX: Float = 0f,
    val wasdVectorY: Float = 0f,
    val sprinting: Boolean = false,
    val aimDeltaX: Float = 0f,
    val aimDeltaY: Float = 0f,
    val firingActive: Boolean = false,
    val lastEventSummary: String = "Waiting for keyboard / mouse input"
)

class InputCaptureProcessor(
    private val touchEngine: TouchInjectionEngine
) {
    private val _runtimeState = MutableStateFlow(InputRuntimeState())
    val runtimeState: StateFlow<InputRuntimeState> = _runtimeState.asStateFlow()

    private val pressedKeys = mutableSetOf<Int>()
    private var virtualAimXNorm = 0.68f
    private var virtualAimYNorm = 0.45f
    private var lastAimEventTimeMs = 0L

    var onShootingModeChanged: ((Boolean) -> Unit)? = null
    var onNodeTriggered: ((String) -> Unit)? = null

    fun setShootingMode(locked: Boolean) {
        if (_runtimeState.value.shootingModeLocked != locked) {
            _runtimeState.value = _runtimeState.value.copy(
                shootingModeLocked = locked,
                lastEventSummary = if (locked) "Shooting Mode LOCKED (360° Aim)" else "Cursor UNLOCKED (Loot / Menu)"
            )
            onShootingModeChanged?.invoke(locked)
        }
    }

    fun toggleShootingMode() {
        setShootingMode(!_runtimeState.value.shootingModeLocked)
    }

    fun handleKeyEvent(
        event: KeyEvent,
        profile: GameMappingProfile,
        settings: GlobalSettings
    ): Boolean {
        val code = event.keyCode
        val isDown = event.action == KeyEvent.ACTION_DOWN
        val isUp = event.action == KeyEvent.ACTION_UP

        if (isDown && event.repeatCount == 0 && code == settings.shootingToggleKeyCode && code != 0) {
            toggleShootingMode()
            return true
        }

        if (isDown) pressedKeys.add(code) else if (isUp) pressedKeys.remove(code)

        // WASD 8-way directional movement + Shift Sprint
        if (profile.wasd.enabled && isWasdOrSprintKey(code, profile.wasd.sprintKeyCode)) {
            updateWasdVector(profile)
            return true
        }

        // Mapped KeyNodes
        val matchedNode = profile.keyNodes.firstOrNull { it.keyCode == code && code != 0 }
        if (matchedNode != null) {
            when (matchedNode.actionMode) {
                ActionMode.NORMAL_TAP -> {
                    if (isDown && event.repeatCount == 0) {
                        onNodeTriggered?.invoke(matchedNode.id)
                        touchEngine.injectTap(matchedNode.xNorm, matchedNode.yNorm, matchedNode.keyLabel)
                        _runtimeState.value = _runtimeState.value.copy(
                            lastEventSummary = "Tap ${matchedNode.keyLabel}"
                        )
                    }
                }
                ActionMode.HOLD -> {
                    if (isDown && event.repeatCount == 0) {
                        onNodeTriggered?.invoke(matchedNode.id)
                        touchEngine.injectSwipe(
                            matchedNode.xNorm, matchedNode.yNorm,
                            matchedNode.xNorm, matchedNode.yNorm,
                            durationMs = 280L,
                            label = "Hold ${matchedNode.keyLabel}"
                        )
                        _runtimeState.value = _runtimeState.value.copy(
                            lastEventSummary = "Hold ${matchedNode.keyLabel}"
                        )
                    }
                }
                ActionMode.RAPID_FIRE -> {
                    if (isDown && event.repeatCount == 0) {
                        onNodeTriggered?.invoke(matchedNode.id)
                        touchEngine.startRapidFire(
                            matchedNode.id,
                            matchedNode.xNorm,
                            matchedNode.yNorm,
                            matchedNode.rapidFireHz,
                            matchedNode.keyLabel
                        )
                        _runtimeState.value = _runtimeState.value.copy(
                            lastEventSummary = "Rapid Fire ${matchedNode.keyLabel} (${matchedNode.rapidFireHz}Hz)"
                        )
                    } else if (isUp) {
                        touchEngine.stopRapidFire(matchedNode.id)
                    }
                }
            }
            return true
        }

        // Mapped Macro triggers
        val matchedMacro = profile.macros.firstOrNull { it.triggerKeyCode == code && code != 0 }
        if (matchedMacro != null && isDown && event.repeatCount == 0) {
            onNodeTriggered?.invoke(matchedMacro.id)
            touchEngine.executeMacro(matchedMacro)
            _runtimeState.value = _runtimeState.value.copy(
                lastEventSummary = "Macro: ${matchedMacro.name} (${matchedMacro.steps.size} steps)"
            )
            return true
        }

        return false
    }

    fun handleMouseEvent(
        event: MotionEvent,
        profile: GameMappingProfile,
        settings: GlobalSettings
    ): Boolean {
        val actionMasked = event.actionMasked
        val actionButton = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            event.actionButton
        } else 0

        // Check toggle button (default Right Click)
        if (actionMasked == MotionEvent.ACTION_BUTTON_PRESS &&
            settings.shootingToggleMouseButton != 0 &&
            actionButton == settings.shootingToggleMouseButton
        ) {
            toggleShootingMode()
            return true
        }

        // Fire Node (Left Click)
        if (profile.fire.enabled && (actionMasked == MotionEvent.ACTION_BUTTON_PRESS || actionMasked == MotionEvent.ACTION_DOWN)) {
            val isLeft = actionButton == MotionEvent.BUTTON_PRIMARY ||
                (event.buttonState and MotionEvent.BUTTON_PRIMARY) != 0
            if (isLeft) {
                onNodeTriggered?.invoke("fire")
                _runtimeState.value = _runtimeState.value.copy(
                    firingActive = true,
                    lastEventSummary = "Fire (L-Click) @ (${(profile.fire.xNorm * 100).toInt()}%, ${(profile.fire.yNorm * 100).toInt()}%)"
                )
                touchEngine.injectMultiTouch(
                    wasdStart = currentWasdStart(profile),
                    wasdEnd = currentWasdEnd(profile),
                    aimStart = null,
                    aimEnd = null,
                    tapPoint = profile.fire.xNorm to profile.fire.yNorm,
                    label = "Fire"
                )
                return true
            }
        }

        if (actionMasked == MotionEvent.ACTION_BUTTON_RELEASE || actionMasked == MotionEvent.ACTION_UP) {
            if (_runtimeState.value.firingActive) {
                _runtimeState.value = _runtimeState.value.copy(firingActive = false)
            }
        }

        // Mapped mouse buttons on KeyNodes
        if (actionMasked == MotionEvent.ACTION_BUTTON_PRESS && actionButton != 0) {
            val node = profile.keyNodes.firstOrNull { it.mouseButton == actionButton }
            if (node != null) {
                onNodeTriggered?.invoke(node.id)
                touchEngine.injectTap(node.xNorm, node.yNorm, node.keyLabel)
                _runtimeState.value = _runtimeState.value.copy(lastEventSummary = "Mouse ${node.keyLabel}")
                return true
            }
        }

        // Relative or hover mouse motion
        val dx = extractDeltaX(event)
        val dy = extractDeltaY(event)
        if (dx != 0f || dy != 0f) {
            if (_runtimeState.value.shootingModeLocked && profile.aim.enabled) {
                onNodeTriggered?.invoke("aim")
                val now = System.currentTimeMillis()
                val resetTimeoutMs = (settings.smartViewResetSec * 1000f).toLong()
                if (settings.smartViewEnabled && (now - lastAimEventTimeMs) > resetTimeoutMs) {
                    virtualAimXNorm = profile.aim.xNorm.coerceIn(0.52f, 0.90f)
                    virtualAimYNorm = profile.aim.yNorm.coerceIn(0.18f, 0.82f)
                }
                lastAimEventTimeMs = now

                val sensX = settings.xAxisSensitivity * profile.aim.xSensitivity * 0.00045f
                val sensY = settings.yAxisSensitivity * profile.aim.ySensitivity * 0.00045f
                val nextX = (virtualAimXNorm + dx * sensX).coerceIn(0.51f, 0.96f)
                val nextY = (virtualAimYNorm + dy * sensY).coerceIn(0.10f, 0.90f)

                val recoilPrefix = if (_runtimeState.value.firingActive) "Fire+Aim" else "360° Aim"
                touchEngine.injectMultiTouch(
                    wasdStart = currentWasdStart(profile),
                    wasdEnd = currentWasdEnd(profile),
                    aimStart = virtualAimXNorm to virtualAimYNorm,
                    aimEnd = nextX to nextY,
                    tapPoint = null,
                    label = recoilPrefix
                )

                virtualAimXNorm = nextX
                virtualAimYNorm = nextY
                if (virtualAimXNorm <= 0.52f || virtualAimXNorm >= 0.95f ||
                    virtualAimYNorm <= 0.11f || virtualAimYNorm >= 0.89f
                ) {
                    virtualAimXNorm = profile.aim.xNorm.coerceIn(0.55f, 0.85f)
                    virtualAimYNorm = profile.aim.yNorm.coerceIn(0.25f, 0.75f)
                }

                _runtimeState.value = _runtimeState.value.copy(
                    aimDeltaX = dx,
                    aimDeltaY = dy,
                    lastEventSummary = "$recoilPrefix Δ(${dx.toInt()}, ${dy.toInt()})"
                )
            } else {
                val speed = settings.cursorSpeed * 0.00075f
                val nx = (_runtimeState.value.cursorXNorm + dx * speed).coerceIn(0.01f, 0.99f)
                val ny = (_runtimeState.value.cursorYNorm + dy * speed).coerceIn(0.01f, 0.99f)
                _runtimeState.value = _runtimeState.value.copy(
                    cursorXNorm = nx,
                    cursorYNorm = ny,
                    aimDeltaX = 0f,
                    aimDeltaY = 0f,
                    lastEventSummary = "Cursor (${(nx * 100).toInt()}%, ${(ny * 100).toInt()}%)"
                )
            }
            return true
        }
        return false
    }

    private fun extractDeltaX(event: MotionEvent): Float {
        val rel = event.getAxisValue(MotionEvent.AXIS_RELATIVE_X)
        if (rel != 0f) return rel
        return event.getAxisValue(MotionEvent.AXIS_X).takeIf {
            event.source and android.view.InputDevice.SOURCE_MOUSE_RELATIVE != 0
        } ?: 0f
    }

    private fun extractDeltaY(event: MotionEvent): Float {
        val rel = event.getAxisValue(MotionEvent.AXIS_RELATIVE_Y)
        if (rel != 0f) return rel
        return event.getAxisValue(MotionEvent.AXIS_Y).takeIf {
            event.source and android.view.InputDevice.SOURCE_MOUSE_RELATIVE != 0
        } ?: 0f
    }

    private fun isWasdOrSprintKey(code: Int, sprintKey: Int): Boolean {
        return code == KeyEvent.KEYCODE_W ||
            code == KeyEvent.KEYCODE_A ||
            code == KeyEvent.KEYCODE_S ||
            code == KeyEvent.KEYCODE_D ||
            (sprintKey != 0 && code == sprintKey)
    }

    private fun updateWasdVector(profile: GameMappingProfile) {
        var vx = 0f
        var vy = 0f
        if (KeyEvent.KEYCODE_A in pressedKeys) vx -= 1f
        if (KeyEvent.KEYCODE_D in pressedKeys) vx += 1f
        if (KeyEvent.KEYCODE_W in pressedKeys) vy -= 1f
        if (KeyEvent.KEYCODE_S in pressedKeys) vy += 1f

        val mag = hypot(vx, vy)
        if (mag > 0f) {
            vx /= mag
            vy /= mag
        }
        val sprint = profile.wasd.sprintEnabled && (profile.wasd.sprintKeyCode in pressedKeys)
        _runtimeState.value = _runtimeState.value.copy(
            wasdVectorX = vx,
            wasdVectorY = vy,
            sprinting = sprint,
            lastEventSummary = if (mag > 0f) {
                if (sprint) "WASD Sprint" else "WASD Move"
            } else {
                "WASD Released"
            }
        )
        if (mag > 0f) {
            onNodeTriggered?.invoke("wasd")
            val start = currentWasdStart(profile)
            val end = currentWasdEnd(profile)
            if (start != null && end != null) {
                touchEngine.injectSwipe(start.first, start.second, end.first, end.second, 95L, "WASD")
            }
        }
    }

    private fun currentWasdStart(profile: GameMappingProfile): Pair<Float, Float>? {
        val state = _runtimeState.value
        if (!profile.wasd.enabled || (state.wasdVectorX == 0f && state.wasdVectorY == 0f)) return null
        return profile.wasd.xNorm to profile.wasd.yNorm
    }

    private fun currentWasdEnd(profile: GameMappingProfile): Pair<Float, Float>? {
        val state = _runtimeState.value
        if (!profile.wasd.enabled || (state.wasdVectorX == 0f && state.wasdVectorY == 0f)) return null
        val mult = if (state.sprinting) 1.38f else 1.0f
        val radiusNorm = (profile.wasd.radiusDp / 750f) * mult
        return (profile.wasd.xNorm + state.wasdVectorX * radiusNorm).coerceIn(0.02f, 0.98f) to
            (profile.wasd.yNorm + state.wasdVectorY * radiusNorm).coerceIn(0.02f, 0.98f)
    }

    fun clearAll() {
        pressedKeys.clear()
        touchEngine.stopAll()
        _runtimeState.value = InputRuntimeState()
    }
}
