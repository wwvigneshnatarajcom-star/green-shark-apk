package com.example.input

import android.content.Context
import android.util.DisplayMetrics
import android.view.WindowManager
import com.example.model.MacroSequence
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class TouchInjectionEngine(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _lastGestureTelemetry = MutableStateFlow("Idle")
    val lastGestureTelemetry: StateFlow<String> = _lastGestureTelemetry.asStateFlow()

    private val rapidFireJobs = mutableMapOf<String, Job>()
    private var activeMacroJob: Job? = null

    fun getScreenBounds(): Pair<Int, Int> {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            val bounds = wm.currentWindowMetrics.bounds
            bounds.width() to bounds.height()
        } else {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            metrics.widthPixels to metrics.heightPixels
        }
    }

    fun toScreenCoords(xNorm: Float, yNorm: Float): Pair<Float, Float> {
        val (w, h) = getScreenBounds()
        return (xNorm.coerceIn(0.01f, 0.99f) * w) to (yNorm.coerceIn(0.01f, 0.99f) * h)
    }

    fun injectTap(xNorm: Float, yNorm: Float, label: String = "Tap") {
        val (px, py) = toScreenCoords(xNorm, yNorm)
        _lastGestureTelemetry.value = "$label @ (${px.toInt()}, ${py.toInt()})"
        GreenSharkAccessibilityService.getInstance()?.dispatchTap(px, py)
    }

    fun injectSwipe(
        startXNorm: Float,
        startYNorm: Float,
        endXNorm: Float,
        endYNorm: Float,
        durationMs: Long = 60L,
        label: String = "Swipe"
    ) {
        val (sx, sy) = toScreenCoords(startXNorm, startYNorm)
        val (ex, ey) = toScreenCoords(endXNorm, endYNorm)
        _lastGestureTelemetry.value = "$label (${sx.toInt()},${sy.toInt()})→(${ex.toInt()},${ey.toInt()})"
        GreenSharkAccessibilityService.getInstance()?.dispatchSwipe(sx, sy, ex, ey, durationMs)
    }

    fun injectMultiTouch(
        wasdStart: Pair<Float, Float>?,
        wasdEnd: Pair<Float, Float>?,
        aimStart: Pair<Float, Float>?,
        aimEnd: Pair<Float, Float>?,
        tapPoint: Pair<Float, Float>? = null,
        label: String = "MultiTouch"
    ) {
        val strokes = mutableListOf<GreenSharkAccessibilityService.StrokeSpec>()
        if (wasdStart != null && wasdEnd != null) {
            val (sx, sy) = toScreenCoords(wasdStart.first, wasdStart.second)
            val (ex, ey) = toScreenCoords(wasdEnd.first, wasdEnd.second)
            strokes += GreenSharkAccessibilityService.StrokeSpec(
                startX = sx,
                startY = sy,
                endX = ex,
                endY = ey,
                durationMs = 95L
            )
        }
        if (aimStart != null && aimEnd != null) {
            val (sx, sy) = toScreenCoords(aimStart.first, aimStart.second)
            val (ex, ey) = toScreenCoords(aimEnd.first, aimEnd.second)
            strokes += GreenSharkAccessibilityService.StrokeSpec(
                startX = sx,
                startY = sy,
                endX = ex,
                endY = ey,
                durationMs = 45L
            )
        }
        if (tapPoint != null) {
            val (tx, ty) = toScreenCoords(tapPoint.first, tapPoint.second)
            strokes += GreenSharkAccessibilityService.StrokeSpec(
                startX = tx,
                startY = ty,
                endX = tx,
                endY = ty,
                durationMs = 35L
            )
        }
        if (strokes.isNotEmpty()) {
            _lastGestureTelemetry.value = "$label [${strokes.size} strokes]"
            GreenSharkAccessibilityService.getInstance()?.dispatchMultiTouch(strokes)
        }
    }

    fun startRapidFire(id: String, xNorm: Float, yNorm: Float, hz: Int, label: String) {
        if (rapidFireJobs[id]?.isActive == true) return
        val intervalMs = (1000L / hz.coerceIn(2, 30)).coerceAtLeast(33L)
        rapidFireJobs[id] = scope.launch {
            while (true) {
                injectTap(xNorm, yNorm, "Rapid:$label")
                delay(intervalMs)
            }
        }
    }

    fun stopRapidFire(id: String) {
        rapidFireJobs.remove(id)?.cancel()
    }

    fun executeMacro(macro: MacroSequence) {
        activeMacroJob?.cancel()
        activeMacroJob = scope.launch {
            val sorted = macro.steps.sortedBy { it.stepNumber }
            for (step in sorted) {
                injectTap(step.xNorm, step.yNorm, "${macro.name} #${step.stepNumber}")
                delay(step.delayMs.coerceAtLeast(20L))
            }
        }
    }

    fun stopAll() {
        rapidFireJobs.values.forEach { it.cancel() }
        rapidFireJobs.clear()
        activeMacroJob?.cancel()
        activeMacroJob = null
    }
}
