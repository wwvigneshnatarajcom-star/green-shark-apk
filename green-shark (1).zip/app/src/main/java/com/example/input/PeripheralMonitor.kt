package com.example.input

import android.content.Context
import android.hardware.input.InputManager
import android.os.Handler
import android.os.Looper
import android.view.InputDevice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class PeripheralStatus(
    val keyboardConnected: Boolean = false,
    val mouseConnected: Boolean = false,
    val keyboardName: String? = null,
    val mouseName: String? = null
)

class PeripheralMonitor(context: Context) {

    private val inputManager = context.getSystemService(Context.INPUT_SERVICE) as InputManager
    private val _status = MutableStateFlow(PeripheralStatus())
    val status: StateFlow<PeripheralStatus> = _status.asStateFlow()

    private val listener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) = refresh()
        override fun onInputDeviceRemoved(deviceId: Int) = refresh()
        override fun onInputDeviceChanged(deviceId: Int) = refresh()
    }

    init {
        refresh()
    }

    fun start() {
        refresh()
        inputManager.registerInputDeviceListener(listener, Handler(Looper.getMainLooper()))
    }

    fun stop() {
        try {
            inputManager.unregisterInputDeviceListener(listener)
        } catch (_: Exception) {
        }
    }

    fun refresh() {
        var kbName: String? = null
        var mouseName: String? = null

        val ids = inputManager.inputDeviceIds
        for (id in ids) {
            val device = inputManager.getInputDevice(id) ?: continue
            if (device.isVirtual) continue
            val sources = device.sources

            val isKeyboard = (sources and InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD &&
                device.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC &&
                isExternalOrPhysicalKeyboard(device)

            val isMouse = (sources and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE ||
                (sources and InputDevice.SOURCE_MOUSE_RELATIVE) == InputDevice.SOURCE_MOUSE_RELATIVE

            if (isKeyboard && kbName == null) {
                kbName = device.name.ifBlank { "External Keyboard" }
            }
            if (isMouse && mouseName == null) {
                mouseName = device.name.ifBlank { "Gaming Mouse" }
            }
        }

        _status.value = PeripheralStatus(
            keyboardConnected = kbName != null,
            mouseConnected = mouseName != null,
            keyboardName = kbName,
            mouseName = mouseName
        )
    }

    private fun isExternalOrPhysicalKeyboard(device: InputDevice): Boolean {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            if (device.isExternal) return true
        }
        val nameLower = device.name.lowercase()
        return !nameLower.contains("virtual") && !nameLower.contains("gpio")
    }
}
