package com.example.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import com.example.model.ActionMode
import com.example.model.CursorStyle
import com.example.model.GameMappingProfile
import com.example.model.GlobalSettings
import com.example.model.KeyNode
import com.example.model.MacroSequence
import com.example.model.MacroStep
import kotlin.math.hypot

@SuppressLint("ViewConstructor")
class OverlayMappingCanvasView(
    context: Context,
    private val onProfileMutated: (GameMappingProfile) -> Unit,
    private val onKeyNodeTapped: (KeyNode) -> Unit,
    private val onWasdTapped: () -> Unit,
    private val onAimTapped: () -> Unit,
    private val onMacroStepAdded: (Float, Float) -> Unit
) : View(context) {

    var profile: GameMappingProfile = GameMappingProfile.defaultFor("global")
        set(value) {
            field = value
            invalidate()
        }

    var settings: GlobalSettings = GlobalSettings()
        set(value) {
            field = value
            invalidate()
        }

    var isEditMode: Boolean = true
        set(value) {
            field = value
            invalidate()
        }

    var isPlacingMacroPoints: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    var activeMacroId: String? = null
        set(value) {
            field = value
            invalidate()
        }

    var showCustomCursor: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    var cursorXNorm: Float = 0.5f
        set(value) {
            field = value
            if (showCustomCursor) invalidate()
        }

    var cursorYNorm: Float = 0.5f
        set(value) {
            field = value
            if (showCustomCursor) invalidate()
        }

    private val density = resources.displayMetrics.density
    private val neonGreen = Color.parseColor("#00FF66")
    private val neonAmber = Color.parseColor("#FFB800")
    private val nodeFill = Color.parseColor("#CC121A16")
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = neonGreen
        strokeWidth = 2.2f * density
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = nodeFill
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#4400FF66")
        strokeWidth = 6f * density
    }
    private val dashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = neonGreen
        strokeWidth = 2f * density
        pathEffect = DashPathEffect(floatArrayOf(12f * density, 8f * density), 0f)
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F0FAF4")
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val subTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = neonGreen
        textAlign = Paint.Align.CENTER
        textSize = 10f * density
        isFakeBoldText = true
    }
    private val cursorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = neonGreen
    }
    private val cursorOutlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#090D0B")
        strokeWidth = 1.8f * density
    }

    private val flashFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = neonGreen
    }
    private val pulseStartTimes = mutableMapOf<String, Long>()
    private val pulseDurationMs = 180L

    fun triggerNodePulse(nodeId: String) {
        pulseStartTimes[nodeId] = SystemClock.uptimeMillis()
        postInvalidateOnAnimation()
    }

    private fun pulseFactor(nodeId: String, now: Long): Float {
        val start = pulseStartTimes[nodeId] ?: return 0f
        val elapsed = now - start
        if (elapsed >= pulseDurationMs) {
            pulseStartTimes.remove(nodeId)
            return 0f
        }
        val progress = (elapsed.toFloat() / pulseDurationMs).coerceIn(0f, 1f)
        return (1f - progress) * (1f - progress)
    }

    private enum class DragTarget { NONE, WASD, AIM, FIRE, KEY, MACRO_STEP }

    private var dragTarget = DragTarget.NONE
    private var dragItemId: String? = null
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private val touchSlop = 10f * density

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat().coerceAtLeast(1f)
        val h = height.toFloat().coerceAtLeast(1f)
        val now = SystemClock.uptimeMillis()
        val alphaInt = ((if (isEditMode) settings.keyOpacity.coerceAtLeast(0.45f) else settings.keyOpacity) * 255).toInt().coerceIn(0, 255)

        if (alphaInt > 0) {
            if (profile.wasd.enabled) {
                drawWasdNode(canvas, w, h, alphaInt, pulseFactor("wasd", now))
            }
            if (profile.aim.enabled) {
                drawAimNode(canvas, w, h, alphaInt, pulseFactor("aim", now))
            }
            if (profile.fire.enabled) {
                drawFireNode(canvas, w, h, alphaInt, pulseFactor("fire", now))
            }
            profile.keyNodes.forEach { node ->
                drawKeyNode(canvas, w, h, node, alphaInt, pulseFactor(node.id, now))
            }
            profile.macros.forEach { macro ->
                drawMacroSequence(canvas, w, h, macro, alphaInt, pulseFactor(macro.id, now))
            }
        }

        if (isPlacingMacroPoints && isEditMode) {
            subTextPaint.color = neonAmber
            subTextPaint.textSize = 13f * density
            canvas.drawText(
                "MACRO EDITOR ACTIVE: TAP SCREEN TO ADD STEP",
                w / 2f,
                h * 0.88f,
                subTextPaint
            )
            subTextPaint.color = neonGreen
            subTextPaint.textSize = 10f * density
        }

        if (showCustomCursor) {
            drawCustomCursor(canvas, cursorXNorm * w, cursorYNorm * h)
        }

        if (pulseStartTimes.isNotEmpty()) {
            postInvalidateOnAnimation()
        }
    }

    private fun drawWasdNode(canvas: Canvas, w: Float, h: Float, alphaInt: Int, pulse: Float) {
        val cx = profile.wasd.xNorm * w
        val cy = profile.wasd.yNorm * h
        val r = profile.wasd.radiusDp * density * (1f + 0.08f * pulse)

        fillPaint.alpha = (alphaInt * 0.82f).toInt()
        strokePaint.alpha = (alphaInt + (255 - alphaInt) * pulse).toInt().coerceIn(0, 255)
        strokePaint.color = neonGreen
        glowPaint.alpha = ((alphaInt * 0.4f) + 140f * pulse).toInt().coerceIn(0, 255)
        glowPaint.strokeWidth = (6f + 5f * pulse) * density

        canvas.drawCircle(cx, cy, r, glowPaint)
        canvas.drawCircle(cx, cy, r, fillPaint)
        if (pulse > 0f) {
            flashFillPaint.alpha = (pulse * 72f).toInt()
            canvas.drawCircle(cx, cy, r, flashFillPaint)
        }
        canvas.drawCircle(cx, cy, r, strokePaint)
        canvas.drawCircle(cx, cy, r * 0.34f, strokePaint)
        glowPaint.strokeWidth = 6f * density

        textPaint.alpha = alphaInt
        textPaint.textSize = 11f * density
        canvas.drawText("W", cx, cy - r * 0.56f, textPaint)
        canvas.drawText("S", cx, cy + r * 0.68f, textPaint)
        canvas.drawText("A", cx - r * 0.64f, cy + 4f * density, textPaint)
        canvas.drawText("D", cx + r * 0.64f, cy + 4f * density, textPaint)

        if (profile.wasd.sprintEnabled) {
            subTextPaint.alpha = alphaInt
            canvas.drawText("SHIFT", cx, cy + 4f * density, subTextPaint)
        }
    }

    private fun drawAimNode(canvas: Canvas, w: Float, h: Float, alphaInt: Int, pulse: Float) {
        val cx = profile.aim.xNorm * w
        val cy = profile.aim.yNorm * h
        val r = (settings.keyButtonSizeDp * 0.62f) * density * (1f + 0.14f * pulse)

        fillPaint.alpha = alphaInt
        strokePaint.alpha = (alphaInt + (255 - alphaInt) * pulse).toInt().coerceIn(0, 255)
        strokePaint.color = neonGreen
        canvas.drawCircle(cx, cy, r, fillPaint)
        if (pulse > 0f) {
            flashFillPaint.alpha = (pulse * 95f).toInt()
            canvas.drawCircle(cx, cy, r, flashFillPaint)
        }
        canvas.drawCircle(cx, cy, r, strokePaint)

        val arm = r * 0.55f
        canvas.drawLine(cx - arm, cy, cx + arm, cy, strokePaint)
        canvas.drawLine(cx, cy - arm, cx, cy + arm, strokePaint)

        subTextPaint.alpha = alphaInt
        canvas.drawText("360° AIM", cx, cy + r + 13f * density, subTextPaint)
    }

    private fun drawFireNode(canvas: Canvas, w: Float, h: Float, alphaInt: Int, pulse: Float) {
        val cx = profile.fire.xNorm * w
        val cy = profile.fire.yNorm * h
        val r = (settings.keyButtonSizeDp * 0.54f) * density * (1f + 0.18f * pulse)

        fillPaint.alpha = alphaInt
        strokePaint.alpha = (alphaInt + (255 - alphaInt) * pulse).toInt().coerceIn(0, 255)
        strokePaint.color = if (pulse > 0.25f) neonGreen else neonAmber
        canvas.drawCircle(cx, cy, r, fillPaint)
        if (pulse > 0f) {
            flashFillPaint.alpha = (pulse * 120f).toInt()
            canvas.drawCircle(cx, cy, r, flashFillPaint)
        }
        canvas.drawCircle(cx, cy, r, strokePaint)

        textPaint.alpha = alphaInt
        textPaint.textSize = 11f * density
        canvas.drawText("FIRE", cx, cy + 4f * density, textPaint)
        subTextPaint.alpha = alphaInt
        subTextPaint.color = neonAmber
        canvas.drawText("L-CLICK", cx, cy + r + 12f * density, subTextPaint)
        subTextPaint.color = neonGreen
        strokePaint.color = neonGreen
    }

    private fun drawKeyNode(canvas: Canvas, w: Float, h: Float, node: KeyNode, alphaInt: Int, pulse: Float) {
        val cx = node.xNorm * w
        val cy = node.yNorm * h
        val r = (settings.keyButtonSizeDp * 0.5f) * density * (1f + 0.18f * pulse)

        fillPaint.alpha = alphaInt
        strokePaint.alpha = (alphaInt + (255 - alphaInt) * pulse).toInt().coerceIn(0, 255)
        strokePaint.color = neonGreen
        glowPaint.alpha = ((alphaInt * 0.35f) + 170f * pulse).toInt().coerceIn(0, 255)
        glowPaint.strokeWidth = (6f + 6f * pulse) * density

        canvas.drawCircle(cx, cy, r, glowPaint)
        canvas.drawCircle(cx, cy, r, fillPaint)
        if (pulse > 0f) {
            flashFillPaint.alpha = (pulse * 135f).toInt()
            canvas.drawCircle(cx, cy, r, flashFillPaint)
        }
        canvas.drawCircle(cx, cy, r, strokePaint)
        glowPaint.strokeWidth = 6f * density

        textPaint.alpha = alphaInt
        textPaint.textSize = if (node.keyLabel.length > 3) 10f * density else 13f * density
        canvas.drawText(node.keyLabel, cx, cy + 4.5f * density, textPaint)

        if (node.actionMode != ActionMode.NORMAL_TAP) {
            val badge = if (node.actionMode == ActionMode.HOLD) "HOLD" else "${node.rapidFireHz}Hz"
            subTextPaint.alpha = alphaInt
            canvas.drawText(badge, cx, cy + r + 11f * density, subTextPaint)
        }
    }

    private fun drawMacroSequence(canvas: Canvas, w: Float, h: Float, macro: MacroSequence, alphaInt: Int, pulse: Float) {
        val steps = macro.steps.sortedBy { it.stepNumber }
        if (steps.isEmpty()) return

        dashPaint.alpha = alphaInt
        for (i in 0 until steps.size - 1) {
            val a = steps[i]
            val b = steps[i + 1]
            canvas.drawLine(a.xNorm * w, a.yNorm * h, b.xNorm * w, b.yNorm * h, dashPaint)
        }

        val r = 18f * density * (1f + 0.16f * pulse)
        steps.forEach { step ->
            val cx = step.xNorm * w
            val cy = step.yNorm * h
            fillPaint.alpha = alphaInt
            strokePaint.alpha = (alphaInt + (255 - alphaInt) * pulse).toInt().coerceIn(0, 255)
            strokePaint.color = if (macro.id == activeMacroId && pulse == 0f) neonAmber else neonGreen
            canvas.drawCircle(cx, cy, r, fillPaint)
            if (pulse > 0f) {
                flashFillPaint.alpha = (pulse * 120f).toInt()
                canvas.drawCircle(cx, cy, r, flashFillPaint)
            }
            canvas.drawCircle(cx, cy, r, strokePaint)

            textPaint.alpha = alphaInt
            textPaint.textSize = 12f * density
            canvas.drawText("${step.stepNumber}", cx, cy + 4f * density, textPaint)

            subTextPaint.alpha = alphaInt
            canvas.drawText("${step.delayMs}ms", cx, cy + r + 11f * density, subTextPaint)
        }
        strokePaint.color = neonGreen
    }

    private fun drawCustomCursor(canvas: Canvas, x: Float, y: Float) {
        when (settings.cursorStyle) {
            CursorStyle.SHARK_ARROW -> {
                val s = 22f * density
                val path = Path().apply {
                    moveTo(x, y)
                    lineTo(x + s * 0.88f, y + s * 0.45f)
                    lineTo(x + s * 0.46f, y + s * 0.52f)
                    lineTo(x + s * 0.36f, y + s * 0.96f)
                    close()
                }
                canvas.drawPath(path, cursorPaint)
                canvas.drawPath(path, cursorOutlinePaint)
            }
            CursorStyle.GAMING_CROSSHAIR -> {
                val r = 10f * density
                val gap = 4f * density
                strokePaint.color = neonGreen
                strokePaint.alpha = 255
                canvas.drawCircle(x, y, 2.5f * density, cursorPaint)
                canvas.drawLine(x - r, y, x - gap, y, strokePaint)
                canvas.drawLine(x + gap, y, x + r, y, strokePaint)
                canvas.drawLine(x, y - r, x, y - gap, strokePaint)
                canvas.drawLine(x, y + gap, x, y + r, strokePaint)
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!isEditMode) return false
        val w = width.toFloat().coerceAtLeast(1f)
        val h = height.toFloat().coerceAtLeast(1f)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                moved = false
                dragTarget = DragTarget.NONE
                dragItemId = null

                if (isPlacingMacroPoints) {
                    val xNorm = (event.x / w).coerceIn(0.05f, 0.95f)
                    val yNorm = (event.y / h).coerceIn(0.08f, 0.92f)
                    onMacroStepAdded(xNorm, yNorm)
                    return true
                }

                // Hit test KeyNodes first
                val keyRadius = (settings.keyButtonSizeDp * 0.65f) * density
                val hitKey = profile.keyNodes.lastOrNull {
                    hypot(event.x - it.xNorm * w, event.y - it.yNorm * h) <= keyRadius
                }
                if (hitKey != null) {
                    dragTarget = DragTarget.KEY
                    dragItemId = hitKey.id
                    return true
                }

                // Hit test Macro steps
                val hitMacroStep = findHitMacroStep(event.x, event.y, w, h)
                if (hitMacroStep != null) {
                    dragTarget = DragTarget.MACRO_STEP
                    dragItemId = hitMacroStep.id
                    return true
                }

                // Hit test Fire
                if (profile.fire.enabled &&
                    hypot(event.x - profile.fire.xNorm * w, event.y - profile.fire.yNorm * h) <= keyRadius
                ) {
                    dragTarget = DragTarget.FIRE
                    return true
                }

                // Hit test Aim
                if (profile.aim.enabled &&
                    hypot(event.x - profile.aim.xNorm * w, event.y - profile.aim.yNorm * h) <= keyRadius * 1.1f
                ) {
                    dragTarget = DragTarget.AIM
                    return true
                }

                // Hit test WASD
                if (profile.wasd.enabled &&
                    hypot(event.x - profile.wasd.xNorm * w, event.y - profile.wasd.yNorm * h) <= profile.wasd.radiusDp * density
                ) {
                    dragTarget = DragTarget.WASD
                    return true
                }
                return false
            }

            MotionEvent.ACTION_MOVE -> {
                if (dragTarget == DragTarget.NONE) return false
                if (!moved && hypot(event.x - downX, event.y - downY) > touchSlop) {
                    moved = true
                }
                if (moved) {
                    val nx = (event.x / w).coerceIn(0.04f, 0.96f)
                    val ny = (event.y / h).coerceIn(0.06f, 0.94f)
                    profile = when (dragTarget) {
                        DragTarget.WASD -> profile.copy(wasd = profile.wasd.copy(xNorm = nx, yNorm = ny))
                        DragTarget.AIM -> profile.copy(aim = profile.aim.copy(xNorm = nx, yNorm = ny))
                        DragTarget.FIRE -> profile.copy(fire = profile.fire.copy(xNorm = nx, yNorm = ny))
                        DragTarget.KEY -> profile.copy(
                            keyNodes = profile.keyNodes.map {
                                if (it.id == dragItemId) it.copy(xNorm = nx, yNorm = ny) else it
                            }
                        )
                        DragTarget.MACRO_STEP -> profile.copy(
                            macros = profile.macros.map { seq ->
                                seq.copy(
                                    steps = seq.steps.map { step ->
                                        if (step.id == dragItemId) step.copy(xNorm = nx, yNorm = ny) else step
                                    }
                                )
                            }
                        )
                        DragTarget.NONE -> profile
                    }
                    onProfileMutated(profile)
                    invalidate()
                }
                return true
            }

            MotionEvent.ACTION_UP -> {
                if (!moved && dragTarget != DragTarget.NONE) {
                    when (dragTarget) {
                        DragTarget.KEY -> {
                            profile.keyNodes.firstOrNull { it.id == dragItemId }?.let(onKeyNodeTapped)
                        }
                        DragTarget.WASD -> onWasdTapped()
                        DragTarget.AIM -> onAimTapped()
                        else -> {}
                    }
                }
                dragTarget = DragTarget.NONE
                dragItemId = null
                return true
            }
        }
        return false
    }

    private fun findHitMacroStep(x: Float, y: Float, w: Float, h: Float): MacroStep? {
        val hitR = 26f * density
        for (macro in profile.macros) {
            for (step in macro.steps) {
                if (hypot(x - step.xNorm * w, y - step.yNorm * h) <= hitR) {
                    return step
                }
            }
        }
        return null
    }
}
