package com.example.overlay

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import com.example.MainActivity
import com.example.R
import com.example.data.GreenSharkPreferences
import com.example.input.GreenSharkAccessibilityService
import com.example.input.InputCaptureProcessor
import com.example.input.TouchInjectionEngine
import com.example.model.GameMappingProfile
import com.example.model.GlobalSettings
import com.example.model.KeyNode
import com.example.model.MacroSequence
import com.example.model.MacroStep
import kotlin.math.abs
import kotlin.math.hypot

class GreenSharkOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: GreenSharkPreferences
    private lateinit var touchEngine: TouchInjectionEngine
    private lateinit var inputProcessor: InputCaptureProcessor
    private lateinit var dialogManager: OverlayDialogManager

    private lateinit var bubbleView: SharkBubbleView
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private var toolbarView: View? = null
    private var toolbarParams: WindowManager.LayoutParams? = null
    private var canvasView: OverlayMappingCanvasView? = null
    private var canvasParams: WindowManager.LayoutParams? = null

    private val handler = Handler(Looper.getMainLooper())
    private var snapAnimator: ValueAnimator? = null
    private val autoFadeRunnable = Runnable {
        if (settings.bubbleAutoFade && !isToolbarOpen) {
            bubbleView.animate()
                .alpha(0.38f)
                .setDuration(220L)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
    }

    private var profile: GameMappingProfile = GameMappingProfile.defaultFor(GreenSharkPreferences.GLOBAL_FALLBACK_PKG)
    private var settings: GlobalSettings = GlobalSettings()
    private var isToolbarOpen = false
    private var activeMacroIdForPlacement: String? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = GreenSharkPreferences(this)
        touchEngine = TouchInjectionEngine(this)
        inputProcessor = InputCaptureProcessor(touchEngine)
        dialogManager = OverlayDialogManager(this, windowManager)

        startAsForeground()
        loadLatestData()
        setupCanvasOverlay()
        setupFloatingBubble()

        GreenSharkAccessibilityService.externalKeyInterceptor = { event ->
            inputProcessor.handleKeyEvent(event, profile, settings)
        }
        inputProcessor.onShootingModeChanged = { locked ->
            handler.post {
                canvasView?.showCustomCursor = !locked && !isToolbarOpen
            }
        }
        inputProcessor.onNodeTriggered = { nodeId ->
            handler.post {
                canvasView?.triggerNodePulse(nodeId)
            }
        }
        OverlayStateManager.onHomeForegroundChanged = { inHome ->
            handler.post {
                applyHomeVisibility(inHome)
            }
        }
        applyHomeVisibility(OverlayStateManager.isHomeForeground)

        OverlayStateManager.setRunning(true)
    }

    private fun applyHomeVisibility(inHome: Boolean) {
        if (inHome) {
            if (isToolbarOpen) toggleToolbar(false)
            bubbleView.visibility = View.GONE
            canvasView?.visibility = View.GONE
        } else {
            bubbleView.visibility = View.VISIBLE
            canvasView?.visibility = View.VISIBLE
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_OPEN_TOOLBAR -> {
                loadLatestData()
                if (!isToolbarOpen) toggleToolbar(true)
            }
            else -> {
                val pkg = intent?.getStringExtra(EXTRA_PACKAGE_NAME)
                val label = intent?.getStringExtra(EXTRA_GAME_LABEL)
                if (!pkg.isNullOrBlank()) {
                    prefs.saveActiveGamePackage(pkg)
                    OverlayStateManager.setActiveGame(pkg, label ?: pkg)
                }
                loadLatestData()
            }
        }
        return START_STICKY
    }

    private fun loadLatestData() {
        val pkg = OverlayStateManager.activePackage.value.ifBlank { prefs.loadActiveGamePackage() }
        val label = OverlayStateManager.activeGameLabel.value
        profile = prefs.loadProfile(pkg, label)
        settings = prefs.loadGlobalSettings()
        canvasView?.profile = profile
        canvasView?.settings = settings
    }

    private fun startAsForeground() {
        val channelId = "green_shark_overlay_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                getString(R.string.overlay_notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        val notification = builder
            .setContentTitle(getString(R.string.overlay_notification_title))
            .setContentText(getString(R.string.overlay_notification_text))
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun overlayWindowType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    private fun setupCanvasOverlay() {
        canvasView = OverlayMappingCanvasView(
            context = this,
            onProfileMutated = { updated -> profile = updated },
            onKeyNodeTapped = { node ->
                dialogManager.showKeyNodeEditor(
                    node = node,
                    onSave = { edited ->
                        profile = profile.copy(
                            keyNodes = profile.keyNodes.map { if (it.id == edited.id) edited else it }
                        )
                        canvasView?.profile = profile
                    },
                    onDelete = { removed ->
                        profile = profile.copy(
                            keyNodes = profile.keyNodes.filterNot { it.id == removed.id }
                        )
                        canvasView?.profile = profile
                    }
                )
            },
            onWasdTapped = {
                dialogManager.showWasdEditor(profile.wasd) { edited ->
                    profile = profile.copy(wasd = edited)
                    canvasView?.profile = profile
                }
            },
            onAimTapped = {
                dialogManager.showAimEditor(profile.aim) { edited ->
                    profile = profile.copy(aim = edited)
                    canvasView?.profile = profile
                }
            },
            onMacroStepAdded = { xNorm, yNorm ->
                val targetId = activeMacroIdForPlacement
                if (targetId != null) {
                    profile = profile.copy(
                        macros = profile.macros.map { macro ->
                            if (macro.id == targetId) {
                                val nextNum = macro.steps.size + 1
                                macro.copy(
                                    steps = macro.steps + MacroStep(
                                        stepNumber = nextNum,
                                        xNorm = xNorm,
                                        yNorm = yNorm,
                                        delayMs = 120L
                                    )
                                )
                            } else macro
                        }
                    )
                    canvasView?.profile = profile
                }
            }
        ).apply {
            profile = this@GreenSharkOverlayService.profile
            settings = this@GreenSharkOverlayService.settings
            isEditMode = false
        }

        canvasParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        windowManager.addView(canvasView, canvasParams)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupFloatingBubble() {
        val density = resources.displayMetrics.density
        val sizePx = (48 * density).toInt()
        bubbleView = SharkBubbleView(this)

        bubbleParams = WindowManager.LayoutParams(
            sizePx,
            sizePx,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (16 * density).toInt()
            y = (110 * density).toInt()
        }

        var startX = 0
        var startY = 0
        var downRawX = 0f
        var downRawY = 0f
        var dragging = false
        val slop = 8 * density

        bubbleView.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    wakeBubble()
                    startX = bubbleParams.x
                    startY = bubbleParams.y
                    downRawX = event.rawX
                    downRawY = event.rawY
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (!dragging && hypot(dx, dy) > slop) {
                        dragging = true
                    }
                    if (dragging) {
                        bubbleParams.x = (startX + dx).toInt()
                        bubbleParams.y = (startY + dy).toInt()
                        windowManager.updateViewLayout(bubbleView, bubbleParams)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) {
                        toggleToolbar(!isToolbarOpen)
                    } else if (settings.bubbleEdgeSnap) {
                        snapBubbleToEdge()
                    }
                    scheduleAutoFade()
                    true
                }
                else -> false
            }
        }

        windowManager.addView(bubbleView, bubbleParams)
        scheduleAutoFade()
    }

    private fun snapBubbleToEdge() {
        val (screenW, _) = touchEngine.getScreenBounds()
        val density = resources.displayMetrics.density
        val margin = (10 * density).toInt()
        val startX = bubbleParams.x
        val center = startX + bubbleView.width / 2
        val targetX = if (center < screenW / 2) margin else (screenW - bubbleView.width - margin)

        snapAnimator?.cancel()
        snapAnimator = ValueAnimator.ofInt(startX, targetX).apply {
            duration = 190L
            interpolator = OvershootInterpolator(1.05f)
            addUpdateListener { anim ->
                if (bubbleView.isAttachedToWindow) {
                    bubbleParams.x = anim.animatedValue as Int
                    try {
                        windowManager.updateViewLayout(bubbleView, bubbleParams)
                    } catch (_: Exception) {
                    }
                }
            }
            start()
        }
    }

    private fun wakeBubble() {
        snapAnimator?.cancel()
        handler.removeCallbacks(autoFadeRunnable)
        bubbleView.animate().alpha(1f).setDuration(150L).start()
    }

    private fun scheduleAutoFade() {
        handler.removeCallbacks(autoFadeRunnable)
        if (settings.bubbleAutoFade && !isToolbarOpen) {
            handler.postDelayed(autoFadeRunnable, 2800L)
        }
    }

    private fun toggleToolbar(open: Boolean) {
        isToolbarOpen = open
        wakeBubble()
        canvasView?.isEditMode = open
        if (!open) {
            canvasView?.isPlacingMacroPoints = false
            activeMacroIdForPlacement = null
        }

        // Toggle canvas touchability so game receives touches when toolbar is hidden
        canvasParams?.let { params ->
            params.flags = if (open) {
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            } else {
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            }
            windowManager.updateViewLayout(canvasView, params)
        }

        if (open) {
            showToolbar()
        } else {
            hideToolbar()
            scheduleAutoFade()
        }
    }

    private fun showToolbar() {
        if (toolbarView != null) return
        val density = resources.displayMetrics.density
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((10 * density).toInt(), (6 * density).toInt(), (10 * density).toInt(), (6 * density).toInt())
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#EB090D0B"))
                cornerRadius = 24f * density
                setStroke((1.5f * density).toInt(), Color.parseColor("#00FF66"))
            }
        }

        fun addToolBtn(label: String, accent: Boolean = false, onClick: () -> Unit) {
            val btn = Button(this).apply {
                text = label
                isAllCaps = false
                textSize = 11.5f
                setPadding((10 * density).toInt(), 0, (10 * density).toInt(), 0)
                setTextColor(if (accent) Color.parseColor("#090D0B") else Color.parseColor("#F0FAF4"))
                background = GradientDrawable().apply {
                    setColor(if (accent) Color.parseColor("#00FF66") else Color.parseColor("#121A16"))
                    cornerRadius = 14f * density
                    setStroke((1 * density).toInt(), Color.parseColor("#1D2B24"))
                }
                setOnClickListener { onClick() }
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                (38 * density).toInt()
            ).apply {
                rightMargin = (5 * density).toInt()
            }
            bar.addView(btn, lp)
        }

        addToolBtn("WASD") {
            val enabled = !profile.wasd.enabled
            profile = profile.copy(wasd = profile.wasd.copy(enabled = enabled))
            canvasView?.profile = profile
            if (enabled) {
                dialogManager.showWasdEditor(profile.wasd) { edited ->
                    profile = profile.copy(wasd = edited)
                    canvasView?.profile = profile
                }
            }
        }

        addToolBtn("+ Key") {
            val newNode = KeyNode(
                keyCode = KeyEvent.KEYCODE_G,
                keyLabel = "G",
                xNorm = 0.5f,
                yNorm = 0.48f
            )
            profile = profile.copy(keyNodes = profile.keyNodes + newNode)
            canvasView?.profile = profile
            dialogManager.showKeyNodeEditor(
                node = newNode,
                onSave = { edited ->
                    profile = profile.copy(
                        keyNodes = profile.keyNodes.map { if (it.id == edited.id) edited else it }
                    )
                    canvasView?.profile = profile
                },
                onDelete = { removed ->
                    profile = profile.copy(
                        keyNodes = profile.keyNodes.filterNot { it.id == removed.id }
                    )
                    canvasView?.profile = profile
                }
            )
        }

        addToolBtn("Aim") {
            profile = profile.copy(aim = profile.aim.copy(enabled = true))
            canvasView?.profile = profile
            dialogManager.showAimEditor(profile.aim) { edited ->
                profile = profile.copy(aim = edited)
                canvasView?.profile = profile
            }
        }

        addToolBtn("Fire") {
            profile = profile.copy(fire = profile.fire.copy(enabled = !profile.fire.enabled))
            canvasView?.profile = profile
        }

        addToolBtn("Macro") {
            val existing = profile.macros.firstOrNull()
            val macro = existing ?: MacroSequence(name = "Macro 1").also {
                profile = profile.copy(macros = profile.macros + it)
                canvasView?.profile = profile
            }
            if (canvasView?.isPlacingMacroPoints == true) {
                canvasView?.isPlacingMacroPoints = false
                activeMacroIdForPlacement = null
            }
            dialogManager.showMacroEditor(
                macro = macro,
                onPlacePoints = {
                    activeMacroIdForPlacement = macro.id
                    canvasView?.activeMacroId = macro.id
                    canvasView?.isPlacingMacroPoints = true
                    Toast.makeText(this, "Tap anywhere to add Macro steps, then tap Macro again to finish.", Toast.LENGTH_SHORT).show()
                },
                onSave = { edited ->
                    profile = profile.copy(
                        macros = profile.macros.map { if (it.id == edited.id) edited else it }
                    )
                    canvasView?.profile = profile
                },
                onDelete = { removed ->
                    profile = profile.copy(
                        macros = profile.macros.filterNot { it.id == removed.id }
                    )
                    canvasView?.profile = profile
                }
            )
        }

        addToolBtn("Settings") {
            dialogManager.showQuickOverlaySettings(settings) { updated ->
                settings = updated
                prefs.saveGlobalSettings(updated)
                canvasView?.settings = updated
                OverlayStateManager.notifyProfileOrSettingsUpdated()
            }
        }

        addToolBtn("Save", accent = true) {
            prefs.saveProfile(profile)
            OverlayStateManager.notifyProfileOrSettingsUpdated()
            Toast.makeText(this, "Saved layout for ${OverlayStateManager.activeGameLabel.value}", Toast.LENGTH_SHORT).show()
        }

        addToolBtn("Hide") {
            prefs.saveProfile(profile)
            toggleToolbar(false)
        }

        addToolBtn("Exit") {
            stopSelf()
        }

        toolbarParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (16 * density).toInt()
        }
        toolbarView = bar
        bar.alpha = 0f
        bar.scaleX = 0.92f
        bar.scaleY = 0.92f
        bar.translationY = -14f * density
        windowManager.addView(bar, toolbarParams)
        bar.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .translationY(0f)
            .setDuration(180L)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    private fun hideToolbar() {
        val view = toolbarView ?: return
        toolbarView = null
        toolbarParams = null
        val density = resources.displayMetrics.density
        view.animate()
            .alpha(0f)
            .scaleX(0.92f)
            .scaleY(0.92f)
            .translationY(-12f * density)
            .setDuration(150L)
            .withEndAction {
                try {
                    windowManager.removeView(view)
                } catch (_: Exception) {
                }
            }
            .start()
    }

    override fun onDestroy() {
        super.onDestroy()
        snapAnimator?.cancel()
        handler.removeCallbacksAndMessages(null)
        OverlayStateManager.onHomeForegroundChanged = null
        GreenSharkAccessibilityService.externalKeyInterceptor = null
        inputProcessor.clearAll()
        dialogManager.dismiss()
        hideToolbar()
        try {
            windowManager.removeView(bubbleView)
        } catch (_: Exception) {
        }
        canvasView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        OverlayStateManager.setRunning(false)
    }

    private class SharkBubbleView(context: Context) : View(context) {
        private val density = resources.displayMetrics.density
        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E6090D0B")
            style = Paint.Style.FILL
        }
        private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#00FF66")
            style = Paint.Style.STROKE
            strokeWidth = 2.2f * density
        }
        private val finPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#00FF66")
            style = Paint.Style.FILL
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f
            val r = (minOf(width, height) / 2f) - 2f * density
            canvas.drawCircle(cx, cy, r, bgPaint)
            canvas.drawCircle(cx, cy, r, borderPaint)

            // Sleek geometric Shark Fin vector
            val finPath = Path().apply {
                moveTo(cx - r * 0.42f, cy + r * 0.36f)
                quadTo(cx - r * 0.10f, cy - r * 0.30f, cx + r * 0.36f, cy - r * 0.45f)
                lineTo(cx + r * 0.18f, cy - r * 0.05f)
                lineTo(cx + r * 0.32f, cy + r * 0.05f)
                lineTo(cx + r * 0.12f, cy + r * 0.14f)
                lineTo(cx + r * 0.38f, cy + r * 0.32f)
                lineTo(cx - r * 0.06f, cy + r * 0.22f)
                close()
            }
            canvas.drawPath(finPath, finPaint)
        }
    }

    companion object {
        const val ACTION_START = "com.example.overlay.START"
        const val ACTION_STOP = "com.example.overlay.STOP"
        const val ACTION_OPEN_TOOLBAR = "com.example.overlay.OPEN_TOOLBAR"
        const val EXTRA_PACKAGE_NAME = "extra_package_name"
        const val EXTRA_GAME_LABEL = "extra_game_label"
        private const val NOTIFICATION_ID = 7001
    }
}
