package com.example.overlay

import android.content.Context
import com.example.data.GreenSharkPreferences
import com.example.model.GameMappingProfile
import com.example.model.GlobalSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object OverlayStateManager {
    private val _isOverlayRunning = MutableStateFlow(false)
    val isOverlayRunning: StateFlow<Boolean> = _isOverlayRunning.asStateFlow()

    private val _activePackage = MutableStateFlow(GreenSharkPreferences.GLOBAL_FALLBACK_PKG)
    val activePackage: StateFlow<String> = _activePackage.asStateFlow()

    private val _activeGameLabel = MutableStateFlow("Global Profile")
    val activeGameLabel: StateFlow<String> = _activeGameLabel.asStateFlow()

    private val _profileVersion = MutableStateFlow(0)
    val profileVersion: StateFlow<Int> = _profileVersion.asStateFlow()

    @Volatile
    var isHomeForeground: Boolean = true
        private set

    var onHomeForegroundChanged: ((Boolean) -> Unit)? = null
    var onOpenAppSettingsRequested: (() -> Unit)? = null

    fun setHomeForeground(inHome: Boolean) {
        isHomeForeground = inHome
        onHomeForegroundChanged?.invoke(inHome)
    }

    fun setRunning(running: Boolean) {
        _isOverlayRunning.value = running
    }

    fun setActiveGame(packageName: String, label: String) {
        _activePackage.value = packageName
        _activeGameLabel.value = label
        _profileVersion.value++
    }

    fun notifyProfileOrSettingsUpdated() {
        _profileVersion.value++
    }

    fun loadCurrentProfile(context: Context): GameMappingProfile {
        val prefs = GreenSharkPreferences(context)
        val pkg = _activePackage.value
        return prefs.loadProfile(pkg, _activeGameLabel.value)
    }

    fun loadCurrentSettings(context: Context): GlobalSettings {
        return GreenSharkPreferences(context).loadGlobalSettings()
    }
}
