package com.example.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import com.example.model.ActionMode
import com.example.model.AimNode
import com.example.model.CursorStyle
import com.example.model.GlobalSettings
import com.example.model.KeyNode
import com.example.model.MacroSequence
import com.example.model.MacroStep
import com.example.model.WasdNode
import com.example.model.formatKeyOrMouseLabel

class OverlayDialogManager(
    private val context: Context,
    private val windowManager: WindowManager
) {
    private var activeDialogView: View? = null
    private val density = context.resources.displayMetrics.density
    private val bgColor = Color.parseColor("#F2121A16")
    private val borderColor = Color.parseColor("#00FF66")
    private val subtleBorder = Color.parseColor("#1D2B24")
    private val textPrimary = Color.parseColor("#F0FAF4")
    private val textSecondary = Color.parseColor("#8BA396")
    private val obsidian = Color.parseColor("#090D0B")

    fun dismiss() {
        activeDialogView?.let { view ->
            try {
                windowManager.removeView(view)
            } catch (_: Exception) {
            }
        }
        activeDialogView = null
    }

    private fun showDialogContent(content: View, widthDp: Int = 380) {
        dismiss()
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val root = FrameLayout(context).apply {
            setBackgroundColor(Color.parseColor("#88000000"))
            setOnClickListener { dismiss() }
        }

        val card = FrameLayout(context).apply {
            background = GradientDrawable().apply {
                setColor(bgColor)
                cornerRadius = 16f * density
                setStroke((1.5f * density).toInt(), borderColor)
            }
            setPadding((18 * density).toInt(), (16 * density).toInt(), (18 * density).toInt(), (16 * density).toInt())
            isClickable = true
            addView(content)
        }

        val cardParams = FrameLayout.LayoutParams(
            (widthDp * density).toInt(),
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER
        )
        root.addView(card, cardParams)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        activeDialogView = root
        root.alpha = 0f
        card.scaleX = 0.93f
        card.scaleY = 0.93f
        windowManager.addView(root, params)
        root.animate().alpha(1f).setDuration(150L).start()
        card.animate()
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(170L)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    @SuppressLint("SetTextI18n")
    fun showKeyNodeEditor(
        node: KeyNode,
        onSave: (KeyNode) -> Unit,
        onDelete: (KeyNode) -> Unit
    ) {
        var currentKeyCode = node.keyCode
        var currentMouseBtn = node.mouseButton
        var currentLabel = node.keyLabel
        var currentMode = node.actionMode
        var currentHz = node.rapidFireHz

        val container = object : LinearLayout(context) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.action == KeyEvent.ACTION_DOWN && event.keyCode != KeyEvent.KEYCODE_BACK) {
                    currentKeyCode = event.keyCode
                    currentMouseBtn = 0
                    currentLabel = formatKeyOrMouseLabel(currentKeyCode, 0)
                    findViewWithTag<TextView>("bind_preview")?.text = "Bound: $currentLabel"
                    return true
                }
                return super.dispatchKeyEvent(event)
            }

            override fun onGenericMotionEvent(event: MotionEvent): Boolean {
                if (event.actionMasked == MotionEvent.ACTION_BUTTON_PRESS) {
                    currentMouseBtn = event.actionButton
                    currentKeyCode = 0
                    currentLabel = formatKeyOrMouseLabel(0, currentMouseBtn)
                    findViewWithTag<TextView>("bind_preview")?.text = "Bound: $currentLabel"
                    return true
                }
                return super.onGenericMotionEvent(event)
            }
        }.apply {
            orientation = LinearLayout.VERTICAL
            isFocusable = true
            isFocusableInTouchMode = true
        }

        container.addView(titleText("KEY NODE CONFIG"))
        val bindBox = TextView(context).apply {
            tag = "bind_preview"
            text = "Press any Key / Mouse button  •  Current: $currentLabel"
            setTextColor(borderColor)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding((12 * density).toInt(), (12 * density).toInt(), (12 * density).toInt(), (12 * density).toInt())
            background = GradientDrawable().apply {
                setColor(obsidian)
                cornerRadius = 10f * density
                setStroke((1 * density).toInt(), borderColor)
            }
        }
        container.addView(bindBox, marginParams(top = 10, bottom = 10))

        // Quick tap presets
        val quickRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            "SPACE" to KeyEvent.KEYCODE_SPACE,
            "SHIFT" to KeyEvent.KEYCODE_SHIFT_LEFT,
            "E" to KeyEvent.KEYCODE_E,
            "R" to KeyEvent.KEYCODE_R,
            "TAB" to KeyEvent.KEYCODE_TAB
        ).forEach { (lbl, kc) ->
            quickRow.addView(pillButton(lbl, false) {
                currentKeyCode = kc
                currentMouseBtn = 0
                currentLabel = lbl
                bindBox.text = "Bound: $lbl"
            }, LinearLayout.LayoutParams(0, (38 * density).toInt(), 1f).apply { rightMargin = (4 * density).toInt() })
        }
        container.addView(quickRow, marginParams(bottom = 10))

        container.addView(subtitleText("Action Mode"))
        val modeRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        val modeButtons = mutableMapOf<ActionMode, Button>()
        ActionMode.entries.forEach { mode ->
            val btn = pillButton(mode.label, mode == currentMode) {
                currentMode = mode
                modeButtons.forEach { (m, b) -> stylePillButton(b, m == currentMode) }
            }
            modeButtons[mode] = btn
            modeRow.addView(btn, LinearLayout.LayoutParams(0, (42 * density).toInt(), 1f).apply { rightMargin = (4 * density).toInt() })
        }
        container.addView(modeRow, marginParams(top = 6, bottom = 10))

        val hzLabel = subtitleText("Rapid Fire Speed: ${currentHz} taps/sec")
        container.addView(hzLabel)
        val hzSeek = SeekBar(context).apply {
            max = 28
            progress = (currentHz - 2).coerceIn(0, 28)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    currentHz = p + 2
                    hzLabel.text = "Rapid Fire Speed: ${currentHz} taps/sec"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        container.addView(hzSeek, marginParams(bottom = 12))

        val actions = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(pillButton("Delete", false, Color.parseColor("#FF4D4F")) {
            onDelete(node)
            dismiss()
        }, LinearLayout.LayoutParams(0, (44 * density).toInt(), 1f).apply { rightMargin = (6 * density).toInt() })
        actions.addView(pillButton("Save Node", true) {
            onSave(
                node.copy(
                    keyCode = currentKeyCode,
                    mouseButton = currentMouseBtn,
                    keyLabel = currentLabel,
                    actionMode = currentMode,
                    rapidFireHz = currentHz
                )
            )
            dismiss()
        }, LinearLayout.LayoutParams(0, (44 * density).toInt(), 1.4f))
        container.addView(actions)

        showDialogContent(container, 420)
        container.requestFocus()
    }

    @SuppressLint("SetTextI18n")
    fun showWasdEditor(wasd: WasdNode, onSave: (WasdNode) -> Unit) {
        var radius = wasd.radiusDp
        var sprint = wasd.sprintEnabled

        val container = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        container.addView(titleText("WASD JOYSTICK WHEEL"))

        val radiusLabel = subtitleText("Wheel Radius: ${radius.toInt()} dp")
        container.addView(radiusLabel, marginParams(top = 10))
        val seek = SeekBar(context).apply {
            max = 84
            progress = (radius - 46f).toInt().coerceIn(0, 84)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    radius = (p + 46).toFloat()
                    radiusLabel.text = "Wheel Radius: ${radius.toInt()} dp"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        container.addView(seek, marginParams(bottom = 10))

        val sprintCheck = CheckBox(context).apply {
            text = "Enable Shift Sprint Modifier (Expands Stick Throw)"
            isChecked = sprint
            setTextColor(textPrimary)
            setOnCheckedChangeListener { _, checked -> sprint = checked }
        }
        container.addView(sprintCheck, marginParams(bottom = 12))

        val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(pillButton("Cancel", false) { dismiss() },
            LinearLayout.LayoutParams(0, (44 * density).toInt(), 1f).apply { rightMargin = (6 * density).toInt() })
        row.addView(pillButton("Apply WASD", true) {
            onSave(wasd.copy(enabled = true, radiusDp = radius, sprintEnabled = sprint))
            dismiss()
        }, LinearLayout.LayoutParams(0, (44 * density).toInt(), 1.2f))
        container.addView(row)

        showDialogContent(container, 370)
    }

    @SuppressLint("SetTextI18n")
    fun showAimEditor(aim: AimNode, onSave: (AimNode) -> Unit) {
        var sensX = aim.xSensitivity
        var sensY = aim.ySensitivity
        var smartView = aim.smartViewEnabled

        val container = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        container.addView(titleText("360° AIM NODE TUNING"))

        val xLabel = subtitleText("X-Axis Sensitivity: ${"%.1f".format(sensX)}x")
        container.addView(xLabel, marginParams(top = 10))
        container.addView(SeekBar(context).apply {
            max = 48
            progress = ((sensX - 0.2f) * 10f).toInt().coerceIn(0, 48)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    sensX = 0.2f + p * 0.1f
                    xLabel.text = "X-Axis Sensitivity: ${"%.1f".format(sensX)}x"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        })

        val yLabel = subtitleText("Y-Axis Sensitivity: ${"%.1f".format(sensY)}x")
        container.addView(yLabel, marginParams(top = 8))
        container.addView(SeekBar(context).apply {
            max = 48
            progress = ((sensY - 0.2f) * 10f).toInt().coerceIn(0, 48)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    sensY = 0.2f + p * 0.1f
                    yLabel.text = "Y-Axis Sensitivity: ${"%.1f".format(sensY)}x"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        })

        val smartCheck = CheckBox(context).apply {
            text = "Smart View Auto-Reset"
            isChecked = smartView
            setTextColor(textPrimary)
            setOnCheckedChangeListener { _, checked -> smartView = checked }
        }
        container.addView(smartCheck, marginParams(top = 6, bottom = 12))

        val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(pillButton("Cancel", false) { dismiss() },
            LinearLayout.LayoutParams(0, (44 * density).toInt(), 1f).apply { rightMargin = (6 * density).toInt() })
        row.addView(pillButton("Apply Aim", true) {
            onSave(aim.copy(enabled = true, xSensitivity = sensX, ySensitivity = sensY, smartViewEnabled = smartView))
            dismiss()
        }, LinearLayout.LayoutParams(0, (44 * density).toInt(), 1.2f))
        container.addView(row)

        showDialogContent(container, 370)
    }

    @SuppressLint("SetTextI18n")
    fun showMacroEditor(
        macro: MacroSequence,
        onPlacePoints: () -> Unit,
        onSave: (MacroSequence) -> Unit,
        onDelete: (MacroSequence) -> Unit
    ) {
        var triggerCode = macro.triggerKeyCode
        var triggerLabel = macro.triggerLabel
        val stepsMutable = macro.steps.toMutableList()

        val container = object : LinearLayout(context) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.action == KeyEvent.ACTION_DOWN && event.keyCode != KeyEvent.KEYCODE_BACK && !hasFocusOnEditText()) {
                    triggerCode = event.keyCode
                    triggerLabel = formatKeyOrMouseLabel(triggerCode, 0)
                    findViewWithTag<TextView>("macro_trigger")?.text = "Trigger Key: $triggerLabel (Press key to change)"
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
            private fun hasFocusOnEditText(): Boolean = findFocus() is EditText
        }.apply {
            orientation = LinearLayout.VERTICAL
            isFocusable = true
            isFocusableInTouchMode = true
        }

        container.addView(titleText("MACRO SEQUENCE EDITOR"))
        val triggerView = TextView(context).apply {
            tag = "macro_trigger"
            text = "Trigger Key: $triggerLabel (Press key to change)"
            setTextColor(borderColor)
            textSize = 12.5f
            setPadding((10 * density).toInt(), (8 * density).toInt(), (10 * density).toInt(), (8 * density).toInt())
            background = GradientDrawable().apply {
                setColor(obsidian)
                cornerRadius = 8f * density
                setStroke((1 * density).toInt(), borderColor)
            }
        }
        container.addView(triggerView, marginParams(top = 8, bottom = 8))

        val stepScroll = ScrollView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (140 * density).toInt()
            )
        }
        val stepsListLayout = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val delayInputs = mutableMapOf<String, EditText>()

        fun rebuildSteps() {
            stepsListLayout.removeAllViews()
            delayInputs.clear()
            if (stepsMutable.isEmpty()) {
                stepsListLayout.addView(subtitleText("No steps yet. Tap 'Place Points on Screen' to add 1, 2, 3..."))
            } else {
                stepsMutable.forEachIndexed { idx, step ->
                    val row = LinearLayout(context).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                    }
                    val info = TextView(context).apply {
                        text = "#${idx + 1} (${(step.xNorm * 100).toInt()}%, ${(step.yNorm * 100).toInt()}%)"
                        setTextColor(textPrimary)
                        textSize = 12f
                    }
                    val delayInput = EditText(context).apply {
                        setText(step.delayMs.toString())
                        inputType = InputType.TYPE_CLASS_NUMBER
                        setTextColor(borderColor)
                        textSize = 12f
                        setBackgroundColor(obsidian)
                        setPadding((8 * density).toInt(), (4 * density).toInt(), (8 * density).toInt(), (4 * density).toInt())
                    }
                    delayInputs[step.id] = delayInput
                    val msUnit = TextView(context).apply {
                        text = " ms"
                        setTextColor(textSecondary)
                        textSize = 11f
                    }
                    row.addView(info, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.4f))
                    row.addView(delayInput, LinearLayout.LayoutParams((70 * density).toInt(), LinearLayout.LayoutParams.WRAP_CONTENT))
                    row.addView(msUnit, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
                    stepsListLayout.addView(row, marginParams(bottom = 4))
                }
            }
        }
        rebuildSteps()
        stepScroll.addView(stepsListLayout)
        container.addView(stepScroll, marginParams(bottom = 10))

        container.addView(pillButton("+ Place Points on Screen", true) {
            val updated = commitStepDelays(stepsMutable, delayInputs)
            onSave(macro.copy(triggerKeyCode = triggerCode, triggerLabel = triggerLabel, steps = updated))
            dismiss()
            onPlacePoints()
        }, marginParams(bottom = 8))

        val actions = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(pillButton("Delete", false, Color.parseColor("#FF4D4F")) {
            onDelete(macro)
            dismiss()
        }, LinearLayout.LayoutParams(0, (42 * density).toInt(), 1f).apply { rightMargin = (6 * density).toInt() })
        actions.addView(pillButton("Save Macro", true) {
            val updated = commitStepDelays(stepsMutable, delayInputs)
            onSave(macro.copy(triggerKeyCode = triggerCode, triggerLabel = triggerLabel, steps = updated))
            dismiss()
        }, LinearLayout.LayoutParams(0, (42 * density).toInt(), 1.4f))
        container.addView(actions)

        showDialogContent(container, 410)
    }

    @SuppressLint("SetTextI18n")
    fun showQuickOverlaySettings(
        settings: GlobalSettings,
        onSave: (GlobalSettings) -> Unit
    ) {
        var current = settings
        val container = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        container.addView(titleText("OVERLAY & AIM SETTINGS"))

        val opacityLabel = subtitleText("Key Opacity: ${(current.keyOpacity * 100).toInt()}%")
        container.addView(opacityLabel, marginParams(top = 8))
        container.addView(SeekBar(context).apply {
            max = 100
            progress = (current.keyOpacity * 100).toInt()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    current = current.copy(keyOpacity = p / 100f)
                    opacityLabel.text = "Key Opacity: $p%"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        })

        val sizeLabel = subtitleText("Key Button Size: ${current.keyButtonSizeDp.toInt()} dp")
        container.addView(sizeLabel, marginParams(top = 6))
        container.addView(SeekBar(context).apply {
            max = 48
            progress = (current.keyButtonSizeDp - 36f).toInt().coerceIn(0, 48)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    current = current.copy(keyButtonSizeDp = (p + 36).toFloat())
                    sizeLabel.text = "Key Button Size: ${p + 36} dp"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        })

        val xSensLabel = subtitleText("Global X Sensitivity: ${"%.1f".format(current.xAxisSensitivity)}x")
        container.addView(xSensLabel, marginParams(top = 6))
        container.addView(SeekBar(context).apply {
            max = 48
            progress = ((current.xAxisSensitivity - 0.2f) * 10f).toInt().coerceIn(0, 48)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = 0.2f + p * 0.1f
                    current = current.copy(xAxisSensitivity = v)
                    xSensLabel.text = "Global X Sensitivity: ${"%.1f".format(v)}x"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        })

        val styleBtn = pillButton("Cursor: ${current.cursorStyle.label}", false) {
            val next = if (current.cursorStyle == CursorStyle.SHARK_ARROW) {
                CursorStyle.GAMING_CROSSHAIR
            } else {
                CursorStyle.SHARK_ARROW
            }
            current = current.copy(cursorStyle = next)
        }
        styleBtn.setOnClickListener {
            val next = if (current.cursorStyle == CursorStyle.SHARK_ARROW) {
                CursorStyle.GAMING_CROSSHAIR
            } else {
                CursorStyle.SHARK_ARROW
            }
            current = current.copy(cursorStyle = next)
            styleBtn.text = "Cursor: ${next.label}"
        }
        container.addView(styleBtn, marginParams(top = 8, bottom = 10))

        val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(pillButton("Close", false) { dismiss() },
            LinearLayout.LayoutParams(0, (44 * density).toInt(), 1f).apply { rightMargin = (6 * density).toInt() })
        row.addView(pillButton("Apply", true) {
            onSave(current)
            dismiss()
        }, LinearLayout.LayoutParams(0, (44 * density).toInt(), 1.2f))
        container.addView(row)

        showDialogContent(container, 400)
    }

    private fun commitStepDelays(
        steps: List<MacroStep>,
        inputs: Map<String, EditText>
    ): List<MacroStep> {
        return steps.mapIndexed { idx, step ->
            val ms = inputs[step.id]?.text?.toString()?.toLongOrNull()?.coerceIn(20L, 5000L) ?: step.delayMs
            step.copy(stepNumber = idx + 1, delayMs = ms)
        }
    }

    private fun titleText(text: String) = TextView(context).apply {
        this.text = text
        setTextColor(borderColor)
        textSize = 15f
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private fun subtitleText(text: String) = TextView(context).apply {
        this.text = text
        setTextColor(textSecondary)
        textSize = 12f
    }

    private fun pillButton(
        text: String,
        selected: Boolean,
        customBorder: Int = borderColor,
        onClick: () -> Unit
    ): Button = Button(context).apply {
        this.text = text
        isAllCaps = false
        textSize = 12f
        minimumHeight = (44 * density).toInt()
        stylePillButton(this, selected, customBorder)
        setOnClickListener { onClick() }
    }

    private fun stylePillButton(btn: Button, selected: Boolean, customBorder: Int = borderColor) {
        btn.setTextColor(if (selected) obsidian else textPrimary)
        btn.background = GradientDrawable().apply {
            setColor(if (selected) customBorder else Color.parseColor("#1D2B24"))
            cornerRadius = 10f * density
            setStroke((1 * density).toInt(), if (selected) customBorder else subtleBorder)
        }
    }

    private fun marginParams(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply {
        topMargin = (top * density).toInt()
        bottomMargin = (bottom * density).toInt()
    }
}
