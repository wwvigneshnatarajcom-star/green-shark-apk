package com.example.model

import android.graphics.drawable.Drawable
import android.view.KeyEvent
import android.view.MotionEvent
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class ActionMode(val label: String) {
    NORMAL_TAP("Normal Tap"),
    HOLD("Hold"),
    RAPID_FIRE("Continuous Rapid Fire");

    companion object {
        fun fromName(name: String?): ActionMode =
            entries.firstOrNull { it.name == name } ?: NORMAL_TAP
    }
}

enum class CursorStyle(val label: String) {
    SHARK_ARROW("Neon Green Shark Arrow"),
    GAMING_CROSSHAIR("Gaming Crosshair");

    companion object {
        fun fromName(name: String?): CursorStyle =
            entries.firstOrNull { it.name == name } ?: SHARK_ARROW
    }
}

enum class ActivationMethod(val label: String) {
    NONE("Not Activated"),
    WIRELESS_ADB("Wireless Debugging"),
    SHIZUKU("Shizuku Service"),
    ACCESSIBILITY("Accessibility Engine"),
    PC_ADB("PC / Second Phone ADB");

    companion object {
        fun fromName(name: String?): ActivationMethod =
            entries.firstOrNull { it.name == name } ?: NONE
    }
}

data class GameEntry(
    val packageName: String,
    val label: String,
    val lastPlayedAt: Long = 0L
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("packageName", packageName)
        put("label", label)
        put("lastPlayedAt", lastPlayedAt)
    }

    companion object {
        fun fromJson(obj: JSONObject): GameEntry = GameEntry(
            packageName = obj.optString("packageName", ""),
            label = obj.optString("label", "Unknown"),
            lastPlayedAt = obj.optLong("lastPlayedAt", 0L)
        )
    }
}

data class InstalledAppInfo(
    val packageName: String,
    val label: String,
    val icon: Drawable?
)

data class WasdNode(
    val enabled: Boolean = true,
    val xNorm: Float = 0.16f,
    val yNorm: Float = 0.72f,
    val radiusDp: Float = 76f,
    val sprintEnabled: Boolean = true,
    val sprintKeyCode: Int = KeyEvent.KEYCODE_SHIFT_LEFT
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("enabled", enabled)
        put("xNorm", xNorm.toDouble())
        put("yNorm", yNorm.toDouble())
        put("radiusDp", radiusDp.toDouble())
        put("sprintEnabled", sprintEnabled)
        put("sprintKeyCode", sprintKeyCode)
    }

    companion object {
        fun fromJson(obj: JSONObject?): WasdNode {
            if (obj == null) return WasdNode()
            return WasdNode(
                enabled = obj.optBoolean("enabled", true),
                xNorm = obj.optDouble("xNorm", 0.16).toFloat().coerceIn(0.05f, 0.95f),
                yNorm = obj.optDouble("yNorm", 0.72).toFloat().coerceIn(0.08f, 0.92f),
                radiusDp = obj.optDouble("radiusDp", 76.0).toFloat().coerceIn(46f, 130f),
                sprintEnabled = obj.optBoolean("sprintEnabled", true),
                sprintKeyCode = obj.optInt("sprintKeyCode", KeyEvent.KEYCODE_SHIFT_LEFT)
            )
        }
    }
}

data class AimNode(
    val enabled: Boolean = true,
    val xNorm: Float = 0.68f,
    val yNorm: Float = 0.45f,
    val xSensitivity: Float = 1.4f,
    val ySensitivity: Float = 1.2f,
    val smartViewEnabled: Boolean = true,
    val smartViewResetSec: Float = 1.5f
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("enabled", enabled)
        put("xNorm", xNorm.toDouble())
        put("yNorm", yNorm.toDouble())
        put("xSensitivity", xSensitivity.toDouble())
        put("ySensitivity", ySensitivity.toDouble())
        put("smartViewEnabled", smartViewEnabled)
        put("smartViewResetSec", smartViewResetSec.toDouble())
    }

    companion object {
        fun fromJson(obj: JSONObject?): AimNode {
            if (obj == null) return AimNode()
            return AimNode(
                enabled = obj.optBoolean("enabled", true),
                xNorm = obj.optDouble("xNorm", 0.68).toFloat().coerceIn(0.1f, 0.95f),
                yNorm = obj.optDouble("yNorm", 0.45).toFloat().coerceIn(0.1f, 0.9f),
                xSensitivity = obj.optDouble("xSensitivity", 1.4).toFloat().coerceIn(0.2f, 5.0f),
                ySensitivity = obj.optDouble("ySensitivity", 1.2).toFloat().coerceIn(0.2f, 5.0f),
                smartViewEnabled = obj.optBoolean("smartViewEnabled", true),
                smartViewResetSec = obj.optDouble("smartViewResetSec", 1.5).toFloat().coerceIn(0.4f, 5.0f)
            )
        }
    }
}

data class FireNode(
    val enabled: Boolean = true,
    val xNorm: Float = 0.85f,
    val yNorm: Float = 0.72f
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("enabled", enabled)
        put("xNorm", xNorm.toDouble())
        put("yNorm", yNorm.toDouble())
    }

    companion object {
        fun fromJson(obj: JSONObject?): FireNode {
            if (obj == null) return FireNode()
            return FireNode(
                enabled = obj.optBoolean("enabled", true),
                xNorm = obj.optDouble("xNorm", 0.85).toFloat().coerceIn(0.05f, 0.95f),
                yNorm = obj.optDouble("yNorm", 0.72).toFloat().coerceIn(0.08f, 0.92f)
            )
        }
    }
}

data class KeyNode(
    val id: String = UUID.randomUUID().toString(),
    val keyCode: Int = 0,
    val mouseButton: Int = 0,
    val keyLabel: String = "?",
    val xNorm: Float = 0.5f,
    val yNorm: Float = 0.5f,
    val actionMode: ActionMode = ActionMode.NORMAL_TAP,
    val rapidFireHz: Int = 12
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("keyCode", keyCode)
        put("mouseButton", mouseButton)
        put("keyLabel", keyLabel)
        put("xNorm", xNorm.toDouble())
        put("yNorm", yNorm.toDouble())
        put("actionMode", actionMode.name)
        put("rapidFireHz", rapidFireHz)
    }

    companion object {
        fun fromJson(obj: JSONObject): KeyNode = KeyNode(
            id = obj.optString("id", UUID.randomUUID().toString()),
            keyCode = obj.optInt("keyCode", 0),
            mouseButton = obj.optInt("mouseButton", 0),
            keyLabel = obj.optString("keyLabel", "?"),
            xNorm = obj.optDouble("xNorm", 0.5).toFloat().coerceIn(0.05f, 0.95f),
            yNorm = obj.optDouble("yNorm", 0.5).toFloat().coerceIn(0.08f, 0.92f),
            actionMode = ActionMode.fromName(obj.optString("actionMode")),
            rapidFireHz = obj.optInt("rapidFireHz", 12).coerceIn(2, 30)
        )
    }
}

data class MacroStep(
    val id: String = UUID.randomUUID().toString(),
    val stepNumber: Int,
    val xNorm: Float,
    val yNorm: Float,
    val delayMs: Long = 120L
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("stepNumber", stepNumber)
        put("xNorm", xNorm.toDouble())
        put("yNorm", yNorm.toDouble())
        put("delayMs", delayMs)
    }

    companion object {
        fun fromJson(obj: JSONObject): MacroStep = MacroStep(
            id = obj.optString("id", UUID.randomUUID().toString()),
            stepNumber = obj.optInt("stepNumber", 1),
            xNorm = obj.optDouble("xNorm", 0.5).toFloat().coerceIn(0.05f, 0.95f),
            yNorm = obj.optDouble("yNorm", 0.5).toFloat().coerceIn(0.08f, 0.92f),
            delayMs = obj.optLong("delayMs", 120L).coerceIn(20L, 5000L)
        )
    }
}

data class MacroSequence(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Macro 1",
    val triggerKeyCode: Int = KeyEvent.KEYCODE_Q,
    val triggerMouseButton: Int = 0,
    val triggerLabel: String = "Q",
    val steps: List<MacroStep> = emptyList()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("triggerKeyCode", triggerKeyCode)
        put("triggerMouseButton", triggerMouseButton)
        put("triggerLabel", triggerLabel)
        put("steps", JSONArray().apply { steps.forEach { put(it.toJson()) } })
    }

    companion object {
        fun fromJson(obj: JSONObject): MacroSequence {
            val arr = obj.optJSONArray("steps") ?: JSONArray()
            val stepsList = buildList {
                for (i in 0 until arr.length()) {
                    arr.optJSONObject(i)?.let { add(MacroStep.fromJson(it)) }
                }
            }
            return MacroSequence(
                id = obj.optString("id", UUID.randomUUID().toString()),
                name = obj.optString("name", "Macro 1"),
                triggerKeyCode = obj.optInt("triggerKeyCode", KeyEvent.KEYCODE_Q),
                triggerMouseButton = obj.optInt("triggerMouseButton", 0),
                triggerLabel = obj.optString("triggerLabel", "Q"),
                steps = stepsList
            )
        }
    }
}

data class GameMappingProfile(
    val packageName: String,
    val profileName: String = "Default Pro",
    val wasd: WasdNode = WasdNode(),
    val aim: AimNode = AimNode(),
    val fire: FireNode = FireNode(),
    val keyNodes: List<KeyNode> = defaultKeyNodes(),
    val macros: List<MacroSequence> = emptyList()
) {
    fun toJsonString(): String = toJson().toString(2)

    fun toJson(): JSONObject = JSONObject().apply {
        put("packageName", packageName)
        put("profileName", profileName)
        put("wasd", wasd.toJson())
        put("aim", aim.toJson())
        put("fire", fire.toJson())
        put("keyNodes", JSONArray().apply { keyNodes.forEach { put(it.toJson()) } })
        put("macros", JSONArray().apply { macros.forEach { put(it.toJson()) } })
    }

    companion object {
        fun defaultKeyNodes(): List<KeyNode> = listOf(
            KeyNode(
                id = "default_space",
                keyCode = KeyEvent.KEYCODE_SPACE,
                keyLabel = "SPACE",
                xNorm = 0.89f,
                yNorm = 0.56f,
                actionMode = ActionMode.NORMAL_TAP
            ),
            KeyNode(
                id = "default_reload",
                keyCode = KeyEvent.KEYCODE_R,
                keyLabel = "R",
                xNorm = 0.77f,
                yNorm = 0.84f,
                actionMode = ActionMode.NORMAL_TAP
            ),
            KeyNode(
                id = "default_crouch",
                keyCode = KeyEvent.KEYCODE_C,
                keyLabel = "C",
                xNorm = 0.90f,
                yNorm = 0.84f,
                actionMode = ActionMode.NORMAL_TAP
            ),
            KeyNode(
                id = "default_interact",
                keyCode = KeyEvent.KEYCODE_F,
                keyLabel = "F",
                xNorm = 0.64f,
                yNorm = 0.62f,
                actionMode = ActionMode.NORMAL_TAP
            )
        )

        fun defaultFor(packageName: String, label: String = "Default Pro"): GameMappingProfile =
            GameMappingProfile(
                packageName = packageName,
                profileName = label
            )

        fun fromJsonString(json: String, fallbackPackage: String = ""): GameMappingProfile? {
            return try {
                val obj = JSONObject(json)
                fromJson(obj, fallbackPackage)
            } catch (_: Exception) {
                null
            }
        }

        fun fromJson(obj: JSONObject, fallbackPackage: String = ""): GameMappingProfile {
            val keysArr = obj.optJSONArray("keyNodes") ?: JSONArray()
            val keyList = buildList {
                for (i in 0 until keysArr.length()) {
                    keysArr.optJSONObject(i)?.let { add(KeyNode.fromJson(it)) }
                }
            }
            val macroArr = obj.optJSONArray("macros") ?: JSONArray()
            val macroList = buildList {
                for (i in 0 until macroArr.length()) {
                    macroArr.optJSONObject(i)?.let { add(MacroSequence.fromJson(it)) }
                }
            }
            return GameMappingProfile(
                packageName = obj.optString("packageName", fallbackPackage).ifBlank { fallbackPackage },
                profileName = obj.optString("profileName", "Default Pro"),
                wasd = WasdNode.fromJson(obj.optJSONObject("wasd")),
                aim = AimNode.fromJson(obj.optJSONObject("aim")),
                fire = FireNode.fromJson(obj.optJSONObject("fire")),
                keyNodes = keyList,
                macros = macroList
            )
        }
    }
}

data class GlobalSettings(
    val xAxisSensitivity: Float = 1.4f,
    val yAxisSensitivity: Float = 1.2f,
    val cursorSpeed: Float = 1.2f,
    val cursorStyle: CursorStyle = CursorStyle.SHARK_ARROW,
    val shootingToggleKeyCode: Int = KeyEvent.KEYCODE_GRAVE,
    val shootingToggleMouseButton: Int = MotionEvent.BUTTON_SECONDARY,
    val shootingToggleLabel: String = "Right Click / ~",
    val smartViewEnabled: Boolean = true,
    val smartViewResetSec: Float = 1.5f,
    val keyOpacity: Float = 0.78f,
    val keyButtonSizeDp: Float = 52f,
    val bubbleEdgeSnap: Boolean = true,
    val bubbleAutoFade: Boolean = true
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("xAxisSensitivity", xAxisSensitivity.toDouble())
        put("yAxisSensitivity", yAxisSensitivity.toDouble())
        put("cursorSpeed", cursorSpeed.toDouble())
        put("cursorStyle", cursorStyle.name)
        put("shootingToggleKeyCode", shootingToggleKeyCode)
        put("shootingToggleMouseButton", shootingToggleMouseButton)
        put("shootingToggleLabel", shootingToggleLabel)
        put("smartViewEnabled", smartViewEnabled)
        put("smartViewResetSec", smartViewResetSec.toDouble())
        put("keyOpacity", keyOpacity.toDouble())
        put("keyButtonSizeDp", keyButtonSizeDp.toDouble())
        put("bubbleEdgeSnap", bubbleEdgeSnap)
        put("bubbleAutoFade", bubbleAutoFade)
    }

    companion object {
        fun fromJsonString(json: String?): GlobalSettings {
            if (json.isNullOrBlank()) return GlobalSettings()
            return try {
                val obj = JSONObject(json)
                GlobalSettings(
                    xAxisSensitivity = obj.optDouble("xAxisSensitivity", 1.4).toFloat().coerceIn(0.2f, 5.0f),
                    yAxisSensitivity = obj.optDouble("yAxisSensitivity", 1.2).toFloat().coerceIn(0.2f, 5.0f),
                    cursorSpeed = obj.optDouble("cursorSpeed", 1.2).toFloat().coerceIn(0.2f, 4.0f),
                    cursorStyle = CursorStyle.fromName(obj.optString("cursorStyle")),
                    shootingToggleKeyCode = obj.optInt("shootingToggleKeyCode", KeyEvent.KEYCODE_GRAVE),
                    shootingToggleMouseButton = obj.optInt("shootingToggleMouseButton", MotionEvent.BUTTON_SECONDARY),
                    shootingToggleLabel = obj.optString("shootingToggleLabel", "Right Click / ~"),
                    smartViewEnabled = obj.optBoolean("smartViewEnabled", true),
                    smartViewResetSec = obj.optDouble("smartViewResetSec", 1.5).toFloat().coerceIn(0.4f, 5.0f),
                    keyOpacity = obj.optDouble("keyOpacity", 0.78).toFloat().coerceIn(0f, 1f),
                    keyButtonSizeDp = obj.optDouble("keyButtonSizeDp", 52.0).toFloat().coerceIn(36f, 84f),
                    bubbleEdgeSnap = obj.optBoolean("bubbleEdgeSnap", true),
                    bubbleAutoFade = obj.optBoolean("bubbleAutoFade", true)
                )
            } catch (_: Exception) {
                GlobalSettings()
            }
        }
    }
}

fun formatKeyOrMouseLabel(keyCode: Int, mouseButton: Int): String {
    if (mouseButton != 0) {
        return when (mouseButton) {
            MotionEvent.BUTTON_PRIMARY -> "L-Click"
            MotionEvent.BUTTON_SECONDARY -> "R-Click"
            MotionEvent.BUTTON_TERTIARY -> "M-Click"
            MotionEvent.BUTTON_BACK -> "Mouse 4"
            MotionEvent.BUTTON_FORWARD -> "Mouse 5"
            else -> "Mouse $mouseButton"
        }
    }
    return when (keyCode) {
        KeyEvent.KEYCODE_GRAVE -> "~"
        KeyEvent.KEYCODE_SPACE -> "SPACE"
        KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT -> "SHIFT"
        KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_CTRL_RIGHT -> "CTRL"
        KeyEvent.KEYCODE_ALT_LEFT, KeyEvent.KEYCODE_ALT_RIGHT -> "ALT"
        KeyEvent.KEYCODE_TAB -> "TAB"
        KeyEvent.KEYCODE_ESCAPE -> "ESC"
        KeyEvent.KEYCODE_ENTER -> "ENTER"
        else -> KeyEvent.keyCodeToString(keyCode)
            .removePrefix("KEYCODE_")
            .take(8)
    }
}
