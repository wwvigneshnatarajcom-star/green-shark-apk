package com.example.ui

import android.app.Application
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Build
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.GreenSharkPreferences
import com.example.data.InstalledAppsRepository
import com.example.input.ActivationEngine
import com.example.input.ActivationState
import com.example.input.InputCaptureProcessor
import com.example.input.PeripheralMonitor
import com.example.input.PeripheralStatus
import com.example.input.TouchInjectionEngine
import com.example.model.GameEntry
import com.example.model.GameMappingProfile
import com.example.model.GlobalSettings
import com.example.model.InstalledAppInfo
import com.example.overlay.GreenSharkOverlayService
import com.example.overlay.OverlayStateManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class ActiveModal {
    NONE,
    ACTIVATION,
    ADD_GAME,
    SETTINGS,
    POINTER_CAPTURE_ARENA
}

data class GameCardUi(
    val entry: GameEntry,
    val icon: Drawable?
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val prefs = GreenSharkPreferences(context)
    private val appsRepo = InstalledAppsRepository(context)
    private val peripheralMonitor = PeripheralMonitor(context)
    private val activationEngine = ActivationEngine(context, prefs)
    val touchEngine = TouchInjectionEngine(context)
    val inputProcessor = InputCaptureProcessor(touchEngine)

    val peripheralStatus: StateFlow<PeripheralStatus> = peripheralMonitor.status
    val activationState: StateFlow<ActivationState> = activationEngine.state
    val isOverlayRunning: StateFlow<Boolean> = OverlayStateManager.isOverlayRunning

    private val _games = MutableStateFlow<List<GameCardUi>>(emptyList())
    val games: StateFlow<List<GameCardUi>> = _games.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _isLoadingApps = MutableStateFlow(false)
    val isLoadingApps: StateFlow<Boolean> = _isLoadingApps.asStateFlow()

    private val _appSearchQuery = MutableStateFlow("")
    val appSearchQuery: StateFlow<String> = _appSearchQuery.asStateFlow()

    private val _globalSettings = MutableStateFlow(prefs.loadGlobalSettings())
    val globalSettings: StateFlow<GlobalSettings> = _globalSettings.asStateFlow()

    private val _selectedProfile = MutableStateFlow(
        prefs.loadProfile(prefs.loadActiveGamePackage(), "Global Profile")
    )
    val selectedProfile: StateFlow<GameMappingProfile> = _selectedProfile.asStateFlow()

    private val _hasOverlayPermission = MutableStateFlow(Settings.canDrawOverlays(context))
    val hasOverlayPermission: StateFlow<Boolean> = _hasOverlayPermission.asStateFlow()

    private val _activeModal = MutableStateFlow(ActiveModal.NONE)
    val activeModal: StateFlow<ActiveModal> = _activeModal.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    init {
        peripheralMonitor.start()
        loadGames()
        OverlayStateManager.onOpenAppSettingsRequested = {
            _activeModal.value = ActiveModal.SETTINGS
        }
    }

    override fun onCleared() {
        super.onCleared()
        peripheralMonitor.stop()
        activationEngine.stopWirelessDiscovery()
        touchEngine.stopAll()
    }

    fun onResumeRefresh() {
        peripheralMonitor.refresh()
        activationEngine.refreshStatus()
        _hasOverlayPermission.value = Settings.canDrawOverlays(context)
        _globalSettings.value = prefs.loadGlobalSettings()
        _selectedProfile.value = prefs.loadProfile(
            _selectedProfile.value.packageName,
            _selectedProfile.value.profileName
        )
    }

    fun openModal(modal: ActiveModal) {
        _activeModal.value = modal
        if (modal == ActiveModal.ADD_GAME && _installedApps.value.isEmpty()) {
            loadInstalledApps()
        }
        if (modal == ActiveModal.ACTIVATION) {
            activationEngine.refreshStatus()
        }
    }

    fun closeModal() {
        if (_activeModal.value == ActiveModal.ACTIVATION) {
            activationEngine.stopWirelessDiscovery()
        }
        _activeModal.value = ActiveModal.NONE
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun loadGames() {
        val saved = prefs.loadAddedGames()
        _games.value = saved.map { entry ->
            GameCardUi(
                entry = entry,
                icon = appsRepo.getAppIcon(entry.packageName)
            )
        }
        val activePkg = prefs.loadActiveGamePackage()
        val matched = saved.firstOrNull { it.packageName == activePkg } ?: saved.firstOrNull()
        if (matched != null) {
            prefs.saveActiveGamePackage(matched.packageName)
            _selectedProfile.value = prefs.loadProfile(matched.packageName, matched.label)
            OverlayStateManager.setActiveGame(matched.packageName, matched.label)
        } else {
            prefs.saveActiveGamePackage(GreenSharkPreferences.GLOBAL_FALLBACK_PKG)
            _selectedProfile.value = prefs.loadProfile(GreenSharkPreferences.GLOBAL_FALLBACK_PKG, "Global Profile")
        }
    }

    fun loadInstalledApps() {
        viewModelScope.launch {
            _isLoadingApps.value = true
            _installedApps.value = appsRepo.getLaunchableApps()
            _isLoadingApps.value = false
        }
    }

    fun setAppSearchQuery(query: String) {
        _appSearchQuery.value = query
    }

    fun addGame(app: InstalledAppInfo) {
        val current = prefs.loadAddedGames().toMutableList()
        if (current.none { it.packageName == app.packageName }) {
            current.add(GameEntry(packageName = app.packageName, label = app.label, lastPlayedAt = System.currentTimeMillis()))
            prefs.saveAddedGames(current)
            prefs.saveProfile(prefs.loadProfile(app.packageName, app.label))
            prefs.saveActiveGamePackage(app.packageName)
            loadGames()
            _toastMessage.value = "Added ${app.label}"
        } else {
            selectProfileForGame(app.packageName, app.label)
            _toastMessage.value = "Selected ${app.label}"
        }
        closeModal()
    }

    fun removeGame(packageName: String) {
        val updated = prefs.loadAddedGames().filterNot { it.packageName == packageName }
        prefs.saveAddedGames(updated)
        if (prefs.loadActiveGamePackage() == packageName) {
            val next = updated.firstOrNull()
            prefs.saveActiveGamePackage(next?.packageName ?: GreenSharkPreferences.GLOBAL_FALLBACK_PKG)
        }
        loadGames()
        _toastMessage.value = "Removed game"
    }

    fun selectProfileForGame(packageName: String, label: String) {
        prefs.saveActiveGamePackage(packageName)
        _selectedProfile.value = prefs.loadProfile(packageName, label)
        OverlayStateManager.setActiveGame(packageName, label)
    }

    fun launchGameWithOverlay(game: GameEntry): Boolean {
        _hasOverlayPermission.value = Settings.canDrawOverlays(context)
        if (!_hasOverlayPermission.value) {
            _toastMessage.value = "Grant 'Display over other apps' permission to launch overlay"
            return false
        }

        prefs.saveActiveGamePackage(game.packageName)
        OverlayStateManager.setActiveGame(game.packageName, game.label)
        _selectedProfile.value = prefs.loadProfile(game.packageName, game.label)

        val updatedList = prefs.loadAddedGames().map {
            if (it.packageName == game.packageName) it.copy(lastPlayedAt = System.currentTimeMillis()) else it
        }
        prefs.saveAddedGames(updatedList)
        loadGames()

        startOverlayService(game.packageName, game.label)

        val launchIntent = appsRepo.getLaunchIntent(game.packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
        } else {
            _toastMessage.value = "Overlay active, but ${game.label} cannot be launched"
        }
        return true
    }

    fun startOverlayService(
        packageName: String = _selectedProfile.value.packageName,
        label: String = _selectedProfile.value.profileName
    ) {
        if (!Settings.canDrawOverlays(context)) {
            _toastMessage.value = "Overlay permission required"
            return
        }
        val intent = Intent(context, GreenSharkOverlayService::class.java).apply {
            action = GreenSharkOverlayService.ACTION_START
            putExtra(GreenSharkOverlayService.EXTRA_PACKAGE_NAME, packageName)
            putExtra(GreenSharkOverlayService.EXTRA_GAME_LABEL, label)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    fun stopOverlayService() {
        val intent = Intent(context, GreenSharkOverlayService::class.java).apply {
            action = GreenSharkOverlayService.ACTION_STOP
        }
        context.startService(intent)
    }

    fun startWirelessDiscovery() {
        activationEngine.startWirelessDiscovery()
    }

    fun pairWirelessDebugging(code: String, port: String) {
        viewModelScope.launch {
            val ok = activationEngine.pairWirelessDebugging(code, port)
            if (ok) {
                _toastMessage.value = "GREEN SHARK Activated via Wireless Debugging"
            }
        }
    }

    fun activateShizuku() {
        val ok = activationEngine.activateWithShizuku()
        if (ok) {
            _toastMessage.value = "Shizuku Service Activated"
        }
    }

    fun openShizukuApp() = activationEngine.openShizukuApp()
    fun openDeveloperOptions() = activationEngine.openDeveloperOptions()
    fun openAccessibilitySettings() = activationEngine.openAccessibilitySettings()
    fun markPcAdbActivated() {
        activationEngine.markPcAdbActivated()
        _toastMessage.value = "PC / Second Phone ADB marked active"
    }

    fun updateGlobalSettings(updated: GlobalSettings) {
        _globalSettings.value = updated
        prefs.saveGlobalSettings(updated)
        OverlayStateManager.notifyProfileOrSettingsUpdated()
    }

    fun saveSelectedProfile(profile: GameMappingProfile) {
        _selectedProfile.value = profile
        prefs.saveProfile(profile)
        OverlayStateManager.notifyProfileOrSettingsUpdated()
        _toastMessage.value = "Profile '${profile.profileName}' saved"
    }

    fun renameSelectedProfile(newName: String) {
        val trimmed = newName.trim().ifBlank { return }
        val updated = _selectedProfile.value.copy(profileName = trimmed)
        saveSelectedProfile(updated)
    }

    fun resetSelectedProfile() {
        val pkg = _selectedProfile.value.packageName
        val label = _games.value.firstOrNull { it.entry.packageName == pkg }?.entry?.label ?: "Default Pro"
        _selectedProfile.value = prefs.resetProfile(pkg, label)
        OverlayStateManager.notifyProfileOrSettingsUpdated()
        _toastMessage.value = "Reset profile to defaults"
    }

    fun exportSelectedProfileJson(): String = _selectedProfile.value.toJsonString()

    fun importProfileJson(jsonText: String): Boolean {
        val currentPkg = _selectedProfile.value.packageName
        val parsed = GameMappingProfile.fromJsonString(jsonText, currentPkg) ?: run {
            _toastMessage.value = "Invalid JSON profile format"
            return false
        }
        val bound = parsed.copy(packageName = currentPkg)
        saveSelectedProfile(bound)
        return true
    }
}
