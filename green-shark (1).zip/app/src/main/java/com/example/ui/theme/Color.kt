package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBg = Color(0xFF090D0B)
val CardSurface = Color(0xFF121A16)
val SurfaceElevated = Color(0xFF17221D)
val CardBorder = Color(0xFF1D2B24)
val NeonGreen = Color(0xFF00FF66)
val NeonGreenDim = Color(0xFF00CC52)
val NeonGreenGlow = Color(0x3300FF66)
val NeonAmber = Color(0xFFFFB800)
val DangerRed = Color(0xFFFF4D4F)
val TextPrimary = Color(0xFFF0FAF4)
val TextSecondary = Color(0xFF8BA396)
val TextMuted = Color(0xFF566B60)
