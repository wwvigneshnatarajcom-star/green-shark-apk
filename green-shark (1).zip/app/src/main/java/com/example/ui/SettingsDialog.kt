package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults.SecondaryIndicator
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.CursorStyle
import com.example.model.GameMappingProfile
import com.example.model.GlobalSettings
import com.example.model.formatKeyOrMouseLabel
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardSurface
import com.example.ui.theme.DangerRed
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SettingsDialog(
    settings: GlobalSettings,
    selectedProfile: GameMappingProfile,
    games: List<GameCardUi>,
    onUpdateSettings: (GlobalSettings) -> Unit,
    onSelectGameProfile: (String, String) -> Unit,
    onSaveProfile: (GameMappingProfile) -> Unit,
    onRenameProfile: (String) -> Unit,
    onResetProfile: () -> Unit,
    onExportJson: () -> String,
    onImportJson: (String) -> Boolean,
    onDismiss: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val context = LocalContext.current

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        AnimatedModalContainer {
            Surface(
                color = CardSurface,
                shape = RoundedCornerShape(22.dp),
                border = BorderStroke(1.dp, NeonGreen.copy(alpha = 0.55f)),
                modifier = Modifier
                    .fillMaxWidth(0.84f)
                    .fillMaxHeight(0.88f)
                    .widthIn(max = 820.dp)
            ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "GREEN SHARK SETTINGS",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                val tabs = listOf("Mouse & 360° Aim", "Overlay & Keys", "Config / Presets")
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = SurfaceElevated,
                    contentColor = NeonGreen,
                    indicator = { positions ->
                        SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(positions[selectedTab]),
                            color = NeonGreen
                        )
                    }
                ) {
                    tabs.forEachIndexed { idx, label ->
                        Tab(
                            selected = selectedTab == idx,
                            onClick = { selectedTab = idx },
                            modifier = Modifier.testTag("settings_tab_$idx"),
                            text = {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (selectedTab == idx) NeonGreen else TextSecondary
                                )
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    when (selectedTab) {
                        0 -> MouseAndAimSettingsTab(settings, onUpdateSettings)
                        1 -> OverlayAppearanceTab(settings, onUpdateSettings)
                        2 -> ConfigPresetManagerTab(
                            context = context,
                            selectedProfile = selectedProfile,
                            games = games,
                            onSelectGameProfile = onSelectGameProfile,
                            onSaveProfile = onSaveProfile,
                            onRenameProfile = onRenameProfile,
                            onResetProfile = onResetProfile,
                            onExportJson = onExportJson,
                            onImportJson = onImportJson
                        )
                    }
                }
            }
            }
        }
    }
}

@Composable
private fun MouseAndAimSettingsTab(
    settings: GlobalSettings,
    onUpdateSettings: (GlobalSettings) -> Unit
) {
    var listeningForToggleKey by remember { mutableStateOf(false) }

    SettingSliderRow(
        title = "X-Axis Sensitivity (Horizontal Camera)",
        valueLabel = "${"%.2f".format(settings.xAxisSensitivity)}x",
        value = settings.xAxisSensitivity,
        range = 0.2f..5.0f,
        onValueChange = { onUpdateSettings(settings.copy(xAxisSensitivity = it)) }
    )
    SettingSliderRow(
        title = "Y-Axis Sensitivity (Vertical Drag / Headshot)",
        valueLabel = "${"%.2f".format(settings.yAxisSensitivity)}x",
        value = settings.yAxisSensitivity,
        range = 0.2f..5.0f,
        onValueChange = { onUpdateSettings(settings.copy(yAxisSensitivity = it)) }
    )
    SettingSliderRow(
        title = "Unlocked Cursor Speed",
        valueLabel = "${"%.2f".format(settings.cursorSpeed)}x",
        value = settings.cursorSpeed,
        range = 0.2f..4.0f,
        onValueChange = { onUpdateSettings(settings.copy(cursorSpeed = it)) }
    )

    // Cursor Style Selector
    Surface(
        color = SurfaceElevated,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, CardBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Cursor Style", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CursorStyle.entries.forEach { style ->
                    val selected = settings.cursorStyle == style
                    Surface(
                        color = if (selected) NeonGreen.copy(alpha = 0.16f) else ObsidianBg,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, if (selected) NeonGreen else CardBorder),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onUpdateSettings(settings.copy(cursorStyle = style)) }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CursorStylePreview(style = style, size = 24.dp)
                            Text(
                                text = style.label,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (selected) NeonGreen else TextPrimary
                            )
                        }
                    }
                }
            }
        }
    }

    // Shooting Mode Toggle Key Binder
    Surface(
        color = SurfaceElevated,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, if (listeningForToggleKey) NeonAmber else CardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .onPreviewKeyEvent { ev ->
                if (listeningForToggleKey && ev.nativeKeyEvent.action == KeyEvent.ACTION_DOWN) {
                    val code = ev.nativeKeyEvent.keyCode
                    if (code != KeyEvent.KEYCODE_BACK) {
                        val label = formatKeyOrMouseLabel(code, 0)
                        onUpdateSettings(
                            settings.copy(
                                shootingToggleKeyCode = code,
                                shootingToggleMouseButton = 0,
                                shootingToggleLabel = label
                            )
                        )
                        listeningForToggleKey = false
                        return@onPreviewKeyEvent true
                    }
                }
                false
            }
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Shooting Mode Toggle Key", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Text(
                        text = "Current: ${settings.shootingToggleLabel}",
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonGreen
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            onUpdateSettings(
                                settings.copy(
                                    shootingToggleKeyCode = KeyEvent.KEYCODE_GRAVE,
                                    shootingToggleMouseButton = MotionEvent.BUTTON_SECONDARY,
                                    shootingToggleLabel = "Right Click / ~"
                                )
                            )
                            listeningForToggleKey = false
                        },
                        border = BorderStroke(1.dp, CardBorder)
                    ) {
                        Text("Default (R-Click / ~)", color = TextSecondary)
                    }
                    Button(
                        onClick = { listeningForToggleKey = !listeningForToggleKey },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (listeningForToggleKey) NeonAmber else NeonGreen,
                            contentColor = ObsidianBg
                        )
                    ) {
                        Text(
                            text = if (listeningForToggleKey) "Press Any Key / Mouse..." else "Rebind Key",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            if (listeningForToggleKey) {
                AndroidView(
                    factory = { ctx ->
                        object : View(ctx) {
                            init {
                                isFocusable = true
                                isFocusableInTouchMode = true
                                requestFocus()
                            }
                            override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
                                val label = formatKeyOrMouseLabel(keyCode, 0)
                                onUpdateSettings(
                                    settings.copy(
                                        shootingToggleKeyCode = keyCode,
                                        shootingToggleMouseButton = 0,
                                        shootingToggleLabel = label
                                    )
                                )
                                listeningForToggleKey = false
                                return true
                            }
                            override fun onGenericMotionEvent(event: MotionEvent): Boolean {
                                if (event.actionMasked == MotionEvent.ACTION_BUTTON_PRESS) {
                                    val btn = event.actionButton
                                    val label = formatKeyOrMouseLabel(0, btn)
                                    onUpdateSettings(
                                        settings.copy(
                                            shootingToggleKeyCode = 0,
                                            shootingToggleMouseButton = btn,
                                            shootingToggleLabel = label
                                        )
                                    )
                                    listeningForToggleKey = false
                                    return true
                                }
                                return super.onGenericMotionEvent(event)
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(36.dp)
                        .background(ObsidianBg, RoundedCornerShape(8.dp))
                )
            }
        }
    }

    // Smart View Auto-Reset
    Surface(
        color = SurfaceElevated,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, CardBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SettingSwitchRow(
                title = "Smart View / 360° Auto-Reset",
                subtitle = "Automatically recenters virtual aim anchor after mouse idle",
                checked = settings.smartViewEnabled,
                onCheckedChange = { onUpdateSettings(settings.copy(smartViewEnabled = it)) }
            )
            if (settings.smartViewEnabled) {
                SettingSliderRow(
                    title = "Auto-Reset Interval",
                    valueLabel = "${"%.1f".format(settings.smartViewResetSec)}s",
                    value = settings.smartViewResetSec,
                    range = 0.4f..5.0f,
                    onValueChange = { onUpdateSettings(settings.copy(smartViewResetSec = it)) }
                )
            }
        }
    }
}

@Composable
private fun OverlayAppearanceTab(
    settings: GlobalSettings,
    onUpdateSettings: (GlobalSettings) -> Unit
) {
    SettingSliderRow(
        title = "Key Transparency / Opacity",
        valueLabel = "${(settings.keyOpacity * 100).toInt()}%",
        value = settings.keyOpacity,
        range = 0.0f..1.0f,
        onValueChange = { onUpdateSettings(settings.copy(keyOpacity = it)) }
    )
    SettingSliderRow(
        title = "Key Button Size",
        valueLabel = "${settings.keyButtonSizeDp.toInt()} dp",
        value = settings.keyButtonSizeDp,
        range = 36f..84f,
        onValueChange = { onUpdateSettings(settings.copy(keyButtonSizeDp = it)) }
    )

    Surface(
        color = SurfaceElevated,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, CardBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SettingSwitchRow(
                title = "Floating Shark Bubble Edge-Snap",
                subtitle = "Snaps bubble to left or right screen edge after dragging",
                checked = settings.bubbleEdgeSnap,
                onCheckedChange = { onUpdateSettings(settings.copy(bubbleEdgeSnap = it)) }
            )
            SettingSwitchRow(
                title = "Floating Shark Bubble Auto-Fade",
                subtitle = "Fades bubble opacity when idle during gameplay",
                checked = settings.bubbleAutoFade,
                onCheckedChange = { onUpdateSettings(settings.copy(bubbleAutoFade = it)) }
            )
        }
    }
}

@Composable
private fun ConfigPresetManagerTab(
    context: Context,
    selectedProfile: GameMappingProfile,
    games: List<GameCardUi>,
    onSelectGameProfile: (String, String) -> Unit,
    onSaveProfile: (GameMappingProfile) -> Unit,
    onRenameProfile: (String) -> Unit,
    onResetProfile: () -> Unit,
    onExportJson: () -> String,
    onImportJson: (String) -> Boolean
) {
    var profileNameInput by remember(selectedProfile.profileName) { mutableStateOf(selectedProfile.profileName) }
    var jsonText by remember(selectedProfile) { mutableStateOf(onExportJson()) }

    // Game switcher row
    if (games.isNotEmpty()) {
        Text("Active Game Profile", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            games.take(5).forEach { g ->
                val isSelected = g.entry.packageName == selectedProfile.packageName
                OutlinedButton(
                    onClick = { onSelectGameProfile(g.entry.packageName, g.entry.label) },
                    border = BorderStroke(1.dp, if (isSelected) NeonGreen else CardBorder),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (isSelected) NeonGreen.copy(alpha = 0.14f) else ObsidianBg
                    )
                ) {
                    Text(g.entry.label, color = if (isSelected) NeonGreen else TextSecondary)
                }
            }
        }
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedTextField(
            value = profileNameInput,
            onValueChange = { profileNameInput = it },
            label = { Text("Profile Name") },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonGreen,
                unfocusedBorderColor = CardBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.weight(1f)
        )
        Button(
            onClick = { onRenameProfile(profileNameInput) },
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = ObsidianBg),
            modifier = Modifier.height(50.dp)
        ) {
            Icon(Icons.Default.Save, null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Save / Rename", fontWeight = FontWeight.Bold)
        }
        OutlinedButton(
            onClick = {
                onResetProfile()
                jsonText = onExportJson()
            },
            border = BorderStroke(1.dp, DangerRed.copy(alpha = 0.6f)),
            modifier = Modifier.height(50.dp)
        ) {
            Icon(Icons.Default.RestartAlt, null, tint = DangerRed, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Reset", color = DangerRed)
        }
    }

    OutlinedTextField(
        value = jsonText,
        onValueChange = { jsonText = it },
        label = { Text("JSON Key-Mapping Config (Export / Import)") },
        minLines = 5,
        maxLines = 7,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NeonGreen,
            unfocusedBorderColor = CardBorder,
            focusedTextColor = NeonGreen,
            unfocusedTextColor = TextPrimary
        ),
        modifier = Modifier.fillMaxWidth()
    )

    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedButton(
            onClick = {
                val exported = onExportJson()
                jsonText = exported
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("GREEN SHARK Profile", exported))
                Toast.makeText(context, "JSON profile copied to clipboard", Toast.LENGTH_SHORT).show()
            },
            border = BorderStroke(1.dp, NeonGreen.copy(alpha = 0.6f)),
            modifier = Modifier.weight(1f).height(46.dp)
        ) {
            Icon(Icons.Default.Upload, null, tint = NeonGreen, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Icon(Icons.Default.ContentCopy, null, tint = NeonGreen, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Export JSON", color = NeonGreen)
        }
        Button(
            onClick = {
                if (onImportJson(jsonText)) {
                    Toast.makeText(context, "Imported profile!", Toast.LENGTH_SHORT).show()
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = ObsidianBg),
            modifier = Modifier.weight(1f).height(46.dp)
        ) {
            Icon(Icons.Default.Download, null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Import JSON", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SettingSliderRow(
    title: String,
    valueLabel: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Surface(
        color = SurfaceElevated,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, CardBorder)
    ) {
        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                Text(valueLabel, style = MaterialTheme.typography.labelLarge, color = NeonGreen)
            }
            Slider(
                value = value,
                onValueChange = onValueChange,
                valueRange = range,
                colors = SliderDefaults.colors(
                    thumbColor = NeonGreen,
                    activeTrackColor = NeonGreen,
                    inactiveTrackColor = CardBorder
                )
            )
        }
    }
}

@Composable
private fun SettingSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = ObsidianBg,
                checkedTrackColor = NeonGreen,
                uncheckedThumbColor = TextSecondary,
                uncheckedTrackColor = ObsidianBg
            )
        )
    }
}
