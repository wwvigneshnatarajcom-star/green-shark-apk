package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val GreenSharkColorScheme = darkColorScheme(
    primary = NeonGreen,
    onPrimary = ObsidianBg,
    primaryContainer = SurfaceElevated,
    onPrimaryContainer = NeonGreen,
    secondary = NeonGreenDim,
    onSecondary = ObsidianBg,
    secondaryContainer = CardSurface,
    onSecondaryContainer = TextPrimary,
    tertiary = NeonAmber,
    onTertiary = ObsidianBg,
    background = ObsidianBg,
    onBackground = TextPrimary,
    surface = CardSurface,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = CardBorder,
    outlineVariant = CardBorder,
    error = DangerRed,
    onError = TextPrimary
)

val GreenSharkShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp)
)

@Composable
fun GreenSharkTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = GreenSharkColorScheme,
        typography = GreenSharkTypography,
        shapes = GreenSharkShapes,
        content = content
    )
}
