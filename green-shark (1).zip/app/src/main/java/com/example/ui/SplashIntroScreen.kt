package com.example.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CardBorder
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun SplashIntroScreen(
    onFinished: () -> Unit
) {
    val logoScale = remember { Animatable(0.72f) }
    val logoAlpha = remember { Animatable(0f) }
    val glowPulse = remember { Animatable(0.3f) }
    val titleAlpha = remember { Animatable(0f) }
    val titleOffsetY = remember { Animatable(18f) }
    val sweepProgress = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        launch {
            logoAlpha.animateTo(1f, tween(durationMillis = 360, easing = FastOutSlowInEasing))
        }
        launch {
            logoScale.animateTo(1.06f, tween(durationMillis = 380, easing = FastOutSlowInEasing))
            logoScale.animateTo(1f, tween(durationMillis = 180, easing = FastOutSlowInEasing))
        }
        launch {
            glowPulse.animateTo(1f, tween(durationMillis = 650, easing = FastOutSlowInEasing))
            glowPulse.animateTo(0.65f, tween(durationMillis = 550, easing = FastOutSlowInEasing))
        }
        launch {
            delay(200L)
            launch {
                titleAlpha.animateTo(1f, tween(durationMillis = 420, easing = FastOutSlowInEasing))
            }
            launch {
                titleOffsetY.animateTo(0f, tween(durationMillis = 420, easing = FastOutSlowInEasing))
            }
        }
        launch {
            delay(260L)
            sweepProgress.animateTo(1f, tween(durationMillis = 1200, easing = LinearEasing))
        }
        delay(1680L)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF0E1D15), ObsidianBg),
                    radius = 950f
                )
            )
            .testTag("splash_intro_screen"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(104.dp)
                    .scale(logoScale.value)
                    .alpha(logoAlpha.value)
                    .drawBehind {
                        val pulse = glowPulse.value
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    NeonGreen.copy(alpha = 0.26f * pulse),
                                    Color.Transparent
                                ),
                                center = Offset(size.width / 2f, size.height / 2f),
                                radius = size.minDimension * 0.72f
                            ),
                            radius = size.minDimension * 0.72f
                        )
                        drawCircle(
                            color = NeonGreen.copy(alpha = 0.45f * pulse),
                            radius = size.minDimension * 0.46f,
                            style = Stroke(width = 1.6.dp.toPx())
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                SharkFinLogo(size = 62.dp)
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier
                    .offset { IntOffset(0, titleOffsetY.value.dp.toPx().roundToInt()) }
                    .alpha(titleAlpha.value),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "GREEN SHARK",
                    style = MaterialTheme.typography.displaySmall.copy(
                        fontSize = 30.sp,
                        letterSpacing = 2.4.sp
                    ),
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Surface(
                    color = NeonGreen.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(6.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonGreen.copy(alpha = 0.55f))
                ) {
                    Text(
                        text = "PRO",
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonGreen,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "ESPORTS PERIPHERAL KEY-MAPPER",
                style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.8.sp),
                color = TextSecondary,
                modifier = Modifier
                    .offset { IntOffset(0, titleOffsetY.value.dp.toPx().roundToInt()) }
                    .alpha(titleAlpha.value)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Sleek neon green loading sweep bar
            Box(
                modifier = Modifier
                    .width(196.dp)
                    .height(3.dp)
                    .clip(RoundedCornerShape(50))
                    .background(CardBorder)
                    .alpha(titleAlpha.value)
            ) {
                Box(
                    modifier = Modifier
                        .width((196f * sweepProgress.value).dp)
                        .height(3.dp)
                        .clip(RoundedCornerShape(50))
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(NeonGreen.copy(alpha = 0.45f), NeonGreen)
                            )
                        )
                )
            }
        }
    }
}
