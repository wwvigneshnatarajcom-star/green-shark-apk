package com.example.ui

import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.CursorStyle
import com.example.ui.theme.CardSurface
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenDim

@Composable
fun SharkFinLogo(
    modifier: Modifier = Modifier,
    size: Dp = 32.dp,
    glowColor: Color = NeonGreen
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        // Subtle ambient neon halo
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(glowColor.copy(alpha = 0.28f), Color.Transparent),
                center = Offset(w * 0.5f, h * 0.5f),
                radius = w * 0.62f
            ),
            radius = w * 0.62f
        )

        val finPath = Path().apply {
            moveTo(w * 0.14f, h * 0.84f)
            quadraticTo(w * 0.34f, h * 0.28f, w * 0.84f, h * 0.14f)
            lineTo(w * 0.68f, h * 0.45f)
            lineTo(w * 0.80f, h * 0.54f)
            lineTo(w * 0.62f, h * 0.64f)
            lineTo(w * 0.86f, h * 0.78f)
            lineTo(w * 0.46f, h * 0.70f)
            close()
        }

        drawPath(
            path = finPath,
            brush = Brush.linearGradient(
                colors = listOf(glowColor, NeonGreenDim),
                start = Offset(0f, h),
                end = Offset(w, 0f)
            )
        )
        drawPath(
            path = finPath,
            color = Color.White.copy(alpha = 0.25f),
            style = Stroke(width = w * 0.03f, cap = StrokeCap.Round)
        )

        // Precision reticle dot inside fin
        drawCircle(
            color = Color(0xFF090D0B),
            radius = w * 0.055f,
            center = Offset(w * 0.52f, h * 0.52f)
        )
    }
}

@Composable
fun CursorStylePreview(
    style: CursorStyle,
    modifier: Modifier = Modifier,
    size: Dp = 28.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        when (style) {
            CursorStyle.SHARK_ARROW -> {
                val path = Path().apply {
                    moveTo(w * 0.2f, h * 0.15f)
                    lineTo(w * 0.85f, h * 0.48f)
                    lineTo(w * 0.54f, h * 0.56f)
                    lineTo(w * 0.44f, h * 0.88f)
                    close()
                }
                drawPath(path, color = NeonGreen)
                drawPath(path, color = Color(0xFF090D0B), style = Stroke(width = w * 0.05f))
            }
            CursorStyle.GAMING_CROSSHAIR -> {
                val c = Offset(w * 0.5f, h * 0.5f)
                val r = w * 0.36f
                val gap = w * 0.13f
                drawCircle(color = NeonGreen, radius = w * 0.08f, center = c)
                drawLine(NeonGreen, Offset(c.x - r, c.y), Offset(c.x - gap, c.y), strokeWidth = w * 0.07f, cap = StrokeCap.Round)
                drawLine(NeonGreen, Offset(c.x + gap, c.y), Offset(c.x + r, c.y), strokeWidth = w * 0.07f, cap = StrokeCap.Round)
                drawLine(NeonGreen, Offset(c.x, c.y - r), Offset(c.x, c.y - gap), strokeWidth = w * 0.07f, cap = StrokeCap.Round)
                drawLine(NeonGreen, Offset(c.x, c.y + gap), Offset(c.x, c.y + r), strokeWidth = w * 0.07f, cap = StrokeCap.Round)
            }
        }
    }
}

@Composable
fun DrawableAppIcon(
    drawable: Drawable?,
    contentDescription: String,
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 14.dp
) {
    val imageBitmap = remember(drawable) {
        drawable?.let { drawableToBitmap(it).asImageBitmap() }
    }
    if (imageBitmap != null) {
        Image(
            bitmap = imageBitmap,
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = modifier
                .clip(RoundedCornerShape(cornerRadius))
                .background(CardSurface)
        )
    } else {
        Box(
            modifier = modifier
                .clip(RoundedCornerShape(cornerRadius))
                .background(CardSurface),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.SportsEsports,
                contentDescription = contentDescription,
                tint = NeonGreen
            )
        }
    }
}

private fun drawableToBitmap(drawable: Drawable): Bitmap {
    if (drawable is BitmapDrawable && drawable.bitmap != null) {
        return drawable.bitmap
    }
    val w = drawable.intrinsicWidth.takeIf { it > 0 } ?: 128
    val h = drawable.intrinsicHeight.takeIf { it > 0 } ?: 128
    val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(bitmap)
    drawable.setBounds(0, 0, canvas.width, canvas.height)
    drawable.draw(canvas)
    return bitmap
}
