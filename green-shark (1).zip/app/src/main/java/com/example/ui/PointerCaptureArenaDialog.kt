package com.example.ui

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.Build
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.input.InputCaptureProcessor
import com.example.input.InputRuntimeState
import com.example.model.CursorStyle
import com.example.model.GameMappingProfile
import com.example.model.GlobalSettings
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardSurface
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun PointerCaptureArenaDialog(
    processor: InputCaptureProcessor,
    profile: GameMappingProfile,
    settings: GlobalSettings,
    onDismiss: () -> Unit
) {
    val runtime by processor.runtimeState.collectAsState()
    var arenaViewRef by remember { mutableStateOf<PointerCaptureSurfaceView?>(null) }

    Dialog(
        onDismissRequest = {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                arenaViewRef?.releasePointerCapture()
            }
            onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        AnimatedModalContainer {
            Surface(
                color = CardSurface,
                shape = RoundedCornerShape(22.dp),
                border = BorderStroke(1.dp, NeonGreen.copy(alpha = 0.65f)),
                modifier = Modifier
                .fillMaxWidth(0.88f)
                .fillMaxHeight(0.88f)
                .widthIn(max = 880.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Default.GpsFixed, null, tint = NeonGreen)
                        Text(
                            text = "360° POINTER CAPTURE & INPUT ARENA",
                            style = MaterialTheme.typography.titleLarge,
                            color = TextPrimary
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val next = !runtime.shootingModeLocked
                                processor.setShootingMode(next)
                                arenaViewRef?.applyPointerCapture(next)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (runtime.shootingModeLocked) NeonAmber else NeonGreen,
                                contentColor = ObsidianBg
                            )
                        ) {
                            Text(
                                text = if (runtime.shootingModeLocked) "Unlock Cursor" else "Lock 360° Aim",
                                fontWeight = FontWeight.Bold
                            )
                        }
                        IconButton(
                            onClick = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    arenaViewRef?.releasePointerCapture()
                                }
                                onDismiss()
                            },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Surface(
                    color = ObsidianBg,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, CardBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    AndroidView(
                        factory = { ctx ->
                            PointerCaptureSurfaceView(
                                context = ctx,
                                onKey = { ev -> processor.handleKeyEvent(ev, profile, settings) },
                                onMotion = { ev -> processor.handleMouseEvent(ev, profile, settings) },
                                onShootingSync = { locked ->
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                        if (locked) requestPointerCapture() else releasePointerCapture()
                                    }
                                }
                            ).also { view ->
                                arenaViewRef = view
                                processor.onShootingModeChanged = { locked ->
                                    view.applyPointerCapture(locked)
                                }
                                view.requestFocus()
                            }
                        },
                        update = { view ->
                            view.updateVisualState(runtime, settings.cursorStyle)
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Toggle Key: ${settings.shootingToggleLabel}  •  ${if (runtime.shootingModeLocked) "360° LOCKED" else "CURSOR UNLOCKED"}",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (runtime.shootingModeLocked) NeonGreen else NeonAmber
                    )
                    Text(
                        text = runtime.lastEventSummary,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
            }
            }
        }
    }
}

@SuppressLint("ViewConstructor")
private class PointerCaptureSurfaceView(
    context: Context,
    private val onKey: (KeyEvent) -> Boolean,
    private val onMotion: (MotionEvent) -> Boolean,
    private val onShootingSync: PointerCaptureSurfaceView.(Boolean) -> Unit
) : View(context) {

    private var runtime = InputRuntimeState()
    private var cursorStyle = CursorStyle.SHARK_ARROW
    private val density = resources.displayMetrics.density

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1D2B24")
        strokeWidth = 1f * density
    }
    private val neonPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00FF66")
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00FF66")
        style = Paint.Style.FILL
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8BA396")
        textSize = 13f * density
        textAlign = Paint.Align.CENTER
    }

    init {
        isFocusable = true
        isFocusableInTouchMode = true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            setOnCapturedPointerListener { _, event ->
                onMotion(event)
            }
        }
    }

    fun applyPointerCapture(locked: Boolean) {
        onShootingSync(locked)
        invalidate()
    }

    fun updateVisualState(state: InputRuntimeState, style: CursorStyle) {
        runtime = state
        cursorStyle = style
        invalidate()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (onKey(event)) return true
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (onKey(event)) return true
        return super.onKeyUp(keyCode, event)
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (onMotion(event)) return true
        return super.onGenericMotionEvent(event)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        requestFocus()
        if (onMotion(event)) return true
        return super.onTouchEvent(event)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()

        // Tactical grid + right-half 360 aim zone divider
        val step = 48f * density
        var x = step
        while (x < w) {
            canvas.drawLine(x, 0f, x, h, gridPaint)
            x += step
        }
        var y = step
        while (y < h) {
            canvas.drawLine(0f, y, w, y, gridPaint)
            y += step
        }
        canvas.drawLine(w / 2f, 0f, w / 2f, h, neonPaint.apply { alpha = 80 })
        neonPaint.alpha = 255

        // Left WASD vector indicator
        val wasdCx = w * 0.22f
        val wasdCy = h * 0.62f
        val wasdR = 54f * density
        canvas.drawCircle(wasdCx, wasdCy, wasdR, neonPaint)
        canvas.drawCircle(
            wasdCx + runtime.wasdVectorX * wasdR * 0.65f,
            wasdCy + runtime.wasdVectorY * wasdR * 0.65f,
            14f * density,
            fillPaint
        )
        canvas.drawText(
            if (runtime.sprinting) "WASD + SHIFT SPRINT" else "WASD VECTOR",
            wasdCx,
            wasdCy + wasdR + 20f * density,
            labelPaint
        )

        // Right 360 Aim Reticle
        val aimCx = w * 0.75f
        val aimCy = h * 0.5f
        canvas.drawCircle(aimCx, aimCy, 44f * density, neonPaint)
        canvas.drawCircle(
            (aimCx + runtime.aimDeltaX * 1.2f).coerceIn(w * 0.55f, w * 0.95f),
            (aimCy + runtime.aimDeltaY * 1.2f).coerceIn(h * 0.15f, h * 0.85f),
            8f * density,
            fillPaint
        )
        canvas.drawText(
            if (runtime.shootingModeLocked) "360° AIM ACTIVE (CURSOR HIDDEN)" else "CLICK OR PRESS TOGGLE KEY TO LOCK 360° AIM",
            aimCx,
            aimCy + 68f * density,
            labelPaint
        )

        // Custom cursor when unlocked
        if (!runtime.shootingModeLocked) {
            val cx = runtime.cursorXNorm * w
            val cy = runtime.cursorYNorm * h
            if (cursorStyle == CursorStyle.SHARK_ARROW) {
                val s = 22f * density
                val path = Path().apply {
                    moveTo(cx, cy)
                    lineTo(cx + s * 0.85f, cy + s * 0.45f)
                    lineTo(cx + s * 0.46f, cy + s * 0.52f)
                    lineTo(cx + s * 0.36f, cy + s * 0.95f)
                    close()
                }
                canvas.drawPath(path, fillPaint)
            } else {
                canvas.drawCircle(cx, cy, 4f * density, fillPaint)
                canvas.drawCircle(cx, cy, 11f * density, neonPaint)
            }
        }
    }
}
