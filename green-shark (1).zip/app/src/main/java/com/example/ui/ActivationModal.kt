package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults.SecondaryIndicator
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.input.ActivationState
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardSurface
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ActivationModal(
    state: ActivationState,
    onDismiss: () -> Unit,
    onStartWirelessScan: () -> Unit,
    onPairWireless: (String, String) -> Unit,
    onOpenDeveloperOptions: () -> Unit,
    onActivateShizuku: () -> Unit,
    onOpenShizuku: () -> Unit,
    onOpenAccessibility: () -> Unit,
    onMarkPcAdbActivated: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var pairingCode by remember { mutableStateOf("") }
    var port by remember(state.discoveredPairingPort) {
        mutableStateOf(state.discoveredPairingPort)
    }
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        onStartWirelessScan()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        AnimatedModalContainer {
            Surface(
                color = CardSurface,
                shape = RoundedCornerShape(22.dp),
                border = BorderStroke(1.dp, NeonGreen.copy(alpha = 0.55f)),
                modifier = Modifier
                    .fillMaxWidth(0.76f)
                    .widthIn(max = 720.dp)
            ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SharkFinLogo(size = 26.dp)
                        Text(
                            text = "GREEN SHARK ACTIVATION",
                            style = MaterialTheme.typography.titleLarge,
                            color = TextPrimary
                        )
                        Surface(
                            color = if (state.isActivated) NeonGreen.copy(alpha = 0.16f) else NeonAmber.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = if (state.isActivated) "ACTIVE" else "INACTIVE",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (state.isActivated) NeonGreen else NeonAmber,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 3 GG Mouse Pro Activation Tabs
                val tabs = listOf("Wireless Debugging", "Shizuku Service", "PC / 2nd Phone ADB")
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = SurfaceElevated,
                    contentColor = NeonGreen,
                    indicator = { tabPositions ->
                        SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = NeonGreen
                        )
                    }
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            modifier = Modifier.testTag("activation_tab_$index"),
                            text = {
                                Text(
                                    text = title,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (selectedTab == index) NeonGreen else TextSecondary
                                )
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    when (selectedTab) {
                        0 -> WirelessDebuggingTab(
                            pairingCode = pairingCode,
                            onPairingCodeChange = { if (it.length <= 6 && it.all(Char::isDigit)) pairingCode = it },
                            port = port,
                            onPortChange = { if (it.length <= 5 && it.all(Char::isDigit)) port = it },
                            isBusy = state.isBusy,
                            onScan = onStartWirelessScan,
                            onPair = { onPairWireless(pairingCode, port) },
                            onOpenDeveloperOptions = onOpenDeveloperOptions
                        )
                        1 -> ShizukuTab(
                            state = state,
                            onActivateShizuku = onActivateShizuku,
                            onOpenShizuku = onOpenShizuku,
                            onOpenAccessibility = onOpenAccessibility
                        )
                        2 -> PcAdbGuideTab(
                            context = context,
                            onMarkActivated = onMarkPcAdbActivated
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Live status bar
                Surface(
                    color = ObsidianBg,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, CardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = state.statusMessage,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (state.isActivated) NeonGreen else TextSecondary,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp)
                    )
                }
            }
            }
        }
    }
}

@Composable
private fun WirelessDebuggingTab(
    pairingCode: String,
    onPairingCodeChange: (String) -> Unit,
    port: String,
    onPortChange: (String) -> Unit,
    isBusy: Boolean,
    onScan: () -> Unit,
    onPair: () -> Unit,
    onOpenDeveloperOptions: () -> Unit
) {
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = NeonGreen,
        unfocusedBorderColor = CardBorder,
        focusedTextColor = TextPrimary,
        unfocusedTextColor = TextPrimary,
        focusedLabelColor = NeonGreen,
        unfocusedLabelColor = TextSecondary
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedTextField(
            value = pairingCode,
            onValueChange = onPairingCodeChange,
            label = { Text("6-Digit Pairing Code") },
            placeholder = { Text("123456") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            colors = fieldColors,
            modifier = Modifier
                .weight(1f)
                .testTag("wireless_pairing_code_input")
        )
        OutlinedTextField(
            value = port,
            onValueChange = onPortChange,
            label = { Text("Pairing Port") },
            placeholder = { Text("37123") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            colors = fieldColors,
            modifier = Modifier
                .weight(1f)
                .testTag("wireless_port_input")
        )
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OutlinedButton(
            onClick = onOpenDeveloperOptions,
            border = BorderStroke(1.dp, CardBorder),
            modifier = Modifier
                .weight(1f)
                .height(48.dp)
        ) {
            Icon(Icons.Default.Settings, null, tint = TextSecondary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Developer Options", color = TextPrimary)
        }
        OutlinedButton(
            onClick = onScan,
            border = BorderStroke(1.dp, NeonGreen.copy(alpha = 0.5f)),
            modifier = Modifier
                .weight(0.8f)
                .height(48.dp)
        ) {
            Icon(Icons.Default.Radar, null, tint = NeonGreen, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Scan Port", color = NeonGreen)
        }
        Button(
            onClick = onPair,
            enabled = !isBusy,
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = ObsidianBg),
            modifier = Modifier
                .weight(1.1f)
                .height(48.dp)
                .testTag("pair_wireless_button")
        ) {
            Icon(Icons.Default.Wifi, null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(if (isBusy) "Pairing..." else "Pair & Activate", fontWeight = FontWeight.Bold)
        }
    }

    Text(
        text = "Tip: Open Developer Options → Wireless Debugging → Pair device with pairing code in split screen, then enter the 6-digit code & port.",
        style = MaterialTheme.typography.bodyMedium,
        color = TextSecondary
    )
}

@Composable
private fun ShizukuTab(
    state: ActivationState,
    onActivateShizuku: () -> Unit,
    onOpenShizuku: () -> Unit,
    onOpenAccessibility: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Surface(
            color = SurfaceElevated,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, if (state.shizukuRunning) NeonGreen else CardBorder),
            modifier = Modifier.weight(1f)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Security, null, tint = if (state.shizukuRunning) NeonGreen else NeonAmber)
                    Text("Shizuku Service", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                }
                Text(
                    text = when {
                        state.shizukuRunning -> "Service Running & Ready"
                        state.shizukuInstalled -> "Installed — Start service in Shizuku"
                        else -> "Shizuku not installed"
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = if (state.shizukuRunning) NeonGreen else TextSecondary
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onActivateShizuku,
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = ObsidianBg),
                        modifier = Modifier.height(44.dp).weight(1f)
                    ) {
                        Text("Request Permission", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = onOpenShizuku,
                        border = BorderStroke(1.dp, CardBorder),
                        modifier = Modifier.height(44.dp)
                    ) {
                        Text("Open", color = TextPrimary)
                    }
                }
            }
        }

        Surface(
            color = SurfaceElevated,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, if (state.accessibilityEnabled) NeonGreen else CardBorder),
            modifier = Modifier.weight(1f)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.AccessibilityNew, null, tint = if (state.accessibilityEnabled) NeonGreen else NeonAmber)
                    Text("Accessibility Engine", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                }
                Text(
                    text = if (state.accessibilityEnabled) "Multi-Touch Gesture Fallback Active" else "Zero-ADB Multi-Touch Fallback",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (state.accessibilityEnabled) NeonGreen else TextSecondary
                )
                Button(
                    onClick = onOpenAccessibility,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (state.accessibilityEnabled) NeonGreen.copy(alpha = 0.2f) else NeonAmber,
                        contentColor = if (state.accessibilityEnabled) NeonGreen else ObsidianBg
                    ),
                    modifier = Modifier.fillMaxWidth().height(44.dp)
                ) {
                    Text(
                        text = if (state.accessibilityEnabled) "Enabled in Settings" else "Enable Accessibility",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun PcAdbGuideTab(
    context: Context,
    onMarkActivated: () -> Unit
) {
    val adbCommand = "adb shell appops set ${context.packageName} SYSTEM_ALERT_WINDOW allow && adb shell settings put secure enabled_accessibility_services ${context.packageName}/com.example.input.GreenSharkAccessibilityService"

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "1. Enable USB Debugging on this phone and connect to your PC or second Android device (via OTG).",
            style = MaterialTheme.typography.bodyMedium,
            color = TextPrimary
        )
        Text(
            text = "2. Run the GREEN SHARK activation command below:",
            style = MaterialTheme.typography.bodyMedium,
            color = TextPrimary
        )
        Surface(
            color = ObsidianBg,
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, CardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = adbCommand,
                    style = MaterialTheme.typography.labelSmall,
                    color = NeonGreen,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("GREEN SHARK ADB", adbCommand))
                        Toast.makeText(context, "ADB command copied", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy ADB command", tint = NeonGreen)
                }
            }
        }
        Button(
            onClick = onMarkActivated,
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = ObsidianBg),
            modifier = Modifier.height(46.dp)
        ) {
            Icon(Icons.Default.Computer, null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Icon(Icons.Default.CheckCircle, null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Verify & Activate ADB Mode", fontWeight = FontWeight.Bold)
        }
    }
}
