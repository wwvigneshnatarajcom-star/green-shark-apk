package com.example.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.input.ActivationState
import com.example.input.PeripheralStatus
import com.example.model.GameEntry
import com.example.ui.theme.CardSurface
import com.example.ui.theme.DangerRed
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

private val ConsoleObsidian = Color(0xFF080C0A)
private val DockGlass = Color(0xCC101814)
private val EmeraldGlassBorder = Color(0xFF1A2922)

@Composable
fun HomeScreen(
    games: List<GameCardUi>,
    selectedGamePackage: String,
    selectedProfileName: String,
    peripheralStatus: PeripheralStatus,
    activationState: ActivationState,
    onSelectGame: (GameEntry) -> Unit,
    onOpenActivation: () -> Unit,
    onOpenAddGame: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenPointerArena: () -> Unit,
    onLaunchGame: (GameEntry) -> Unit,
    onConfigureGameProfile: (GameEntry) -> Unit,
    onRemoveGame: (GameEntry) -> Unit
) {
    var pendingDeleteGame by remember { mutableStateOf<GameEntry?>(null) }

    val activeGame = remember(games, selectedGamePackage) {
        games.firstOrNull { it.entry.packageName == selectedGamePackage } ?: games.firstOrNull()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF0C1A13), ConsoleObsidian),
                    radius = 1200f
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // 1. MINIMAL TOP STATUS BAR (~40dp, translucent dark)
            ConsoleTopBar(
                peripheralStatus = peripheralStatus,
                activationState = activationState,
                onOpenActivation = onOpenActivation,
                onOpenPointerArena = onOpenPointerArena,
                onOpenSettings = onOpenSettings
            )

            // 2. CENTER HERO STAGE (Selected Game Showcase — Clean & Spacious)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                AnimatedContent(
                    targetState = activeGame,
                    transitionSpec = {
                        (fadeIn(tween(180)) + scaleIn(initialScale = 0.96f, animationSpec = tween(180)))
                            .togetherWith(fadeOut(tween(130)))
                    },
                    label = "hero_game_transition"
                ) { heroGame ->
                    if (heroGame != null) {
                        HeroGameShowcase(
                            game = heroGame,
                            presetName = selectedProfileName,
                            onLaunch = { onLaunchGame(heroGame.entry) },
                            onEditPreset = { onConfigureGameProfile(heroGame.entry) }
                        )
                    } else {
                        EmptyHeroShowcase(onAddGame = onOpenAddGame)
                    }
                }
            }

            // 3. BOTTOM FLOATING GAME DOCK (Horizontal Carousel)
            BottomFloatingGameDock(
                games = games,
                selectedPackage = activeGame?.entry?.packageName,
                onSelectGame = onSelectGame,
                onLaunchGame = onLaunchGame,
                onConfigureGame = onConfigureGameProfile,
                onAskRemoveGame = { pendingDeleteGame = it },
                onAddGameClick = onOpenAddGame
            )
        }
    }

    pendingDeleteGame?.let { target ->
        AlertDialog(
            onDismissRequest = { pendingDeleteGame = null },
            containerColor = CardSurface,
            titleContentColor = TextPrimary,
            textContentColor = TextSecondary,
            title = { Text("Remove ${target.label}?") },
            text = { Text("This removes ${target.label} from your GREEN SHARK dock.") },
            confirmButton = {
                Button(
                    onClick = {
                        onRemoveGame(target)
                        pendingDeleteGame = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DangerRed, contentColor = TextPrimary)
                ) {
                    Text("Remove")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeleteGame = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun ConsoleTopBar(
    peripheralStatus: PeripheralStatus,
    activationState: ActivationState,
    onOpenActivation: () -> Unit,
    onOpenPointerArena: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val active = activationState.isActivated
    val statusColor = if (active) NeonGreen else NeonAmber

    Surface(
        color = Color(0xB3080C0A),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, EmeraldGlassBorder.copy(alpha = 0.7f)),
        modifier = Modifier
            .fillMaxWidth()
            .height(42.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp)
        ) {
            // Left: Shark Fin emblem + bold GREEN SHARK title
            Row(
                modifier = Modifier.align(Alignment.CenterStart),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SharkFinLogo(size = 22.dp)
                Text(
                    text = "GREEN SHARK",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontSize = 15.sp,
                        letterSpacing = 1.2.sp
                    ),
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            }

            // Center: Clickable Activation State Pill
            val pillInteraction = remember { MutableInteractionSource() }
            val pillPressed by pillInteraction.collectIsPressedAsState()
            val pillScale by animateFloatAsState(
                targetValue = if (pillPressed) 0.95f else 1f,
                animationSpec = tween(150),
                label = "activation_pill_scale"
            )

            Surface(
                onClick = onOpenActivation,
                interactionSource = pillInteraction,
                color = statusColor.copy(alpha = 0.12f),
                shape = CircleShape,
                border = BorderStroke(1.dp, statusColor.copy(alpha = 0.6f)),
                modifier = Modifier
                    .align(Alignment.Center)
                    .height(28.dp)
                    .scale(pillScale)
                    .testTag("activation_pill_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(statusColor)
                    )
                    Text(
                        text = if (active) "ACTIVATED" else "NEED ACTIVATION",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 10.5.sp,
                            letterSpacing = 0.7.sp
                        ),
                        color = statusColor,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Right: Keyboard + Mouse badges (with 🚫 when disconnected) + 360° + Settings gear
            Row(
                modifier = Modifier.align(Alignment.CenterEnd),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CompactPeripheralBadge(
                    icon = Icons.Default.Keyboard,
                    deviceLabel = "Keyboard",
                    connected = peripheralStatus.keyboardConnected,
                    testTag = "status_keyboard"
                )
                CompactPeripheralBadge(
                    icon = Icons.Default.Mouse,
                    deviceLabel = "Mouse",
                    connected = peripheralStatus.mouseConnected,
                    testTag = "status_mouse"
                )
                TopBarIconButton(
                    icon = Icons.Default.GpsFixed,
                    contentDescription = "360 Pointer Capture Arena",
                    tint = NeonGreen,
                    onClick = onOpenPointerArena,
                    testTag = "pointer_arena_button"
                )
                TopBarIconButton(
                    icon = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = TextPrimary,
                    onClick = onOpenSettings,
                    testTag = "settings_button"
                )
            }
        }
    }
}

@Composable
private fun HeroGameShowcase(
    game: GameCardUi,
    presetName: String,
    onLaunch: () -> Unit,
    onEditPreset: () -> Unit
) {
    val launchInteraction = remember { MutableInteractionSource() }
    val launchPressed by launchInteraction.collectIsPressedAsState()
    val launchScale by animateFloatAsState(
        targetValue = if (launchPressed) 0.95f else 1f,
        animationSpec = tween(150),
        label = "launch_btn_scale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.padding(vertical = 6.dp)
    ) {
        // Large crisp rounded icon with subtle #00FF66 ambient glow behind it
        Box(
            modifier = Modifier
                .size(116.dp)
                .drawBehind {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                NeonGreen.copy(alpha = 0.28f),
                                NeonGreen.copy(alpha = 0.08f),
                                Color.Transparent
                            ),
                            center = Offset(size.width / 2f, size.height / 2f),
                            radius = size.minDimension * 0.65f
                        ),
                        radius = size.minDimension * 0.65f
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Surface(
                shape = RoundedCornerShape(22.dp),
                border = BorderStroke(1.5.dp, NeonGreen.copy(alpha = 0.55f)),
                color = CardSurface
            ) {
                DrawableAppIcon(
                    drawable = game.icon,
                    contentDescription = game.entry.label,
                    modifier = Modifier.size(84.dp),
                    cornerRadius = 22.dp
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = game.entry.label,
            style = MaterialTheme.typography.headlineMedium.copy(
                fontSize = 21.sp,
                letterSpacing = 0.6.sp
            ),
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        Spacer(modifier = Modifier.height(4.dp))

        // Active key-map preset pill
        Surface(
            onClick = onEditPreset,
            color = DockGlass,
            shape = CircleShape,
            border = BorderStroke(1.dp, EmeraldGlassBorder)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = null,
                    tint = NeonGreen,
                    modifier = Modifier.size(12.dp)
                )
                Text(
                    text = presetName,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                    color = TextSecondary,
                    maxLines = 1
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Sleek 40dp Neon Green LAUNCH GAME pill button
        Surface(
            onClick = onLaunch,
            interactionSource = launchInteraction,
            shape = CircleShape,
            color = NeonGreen,
            modifier = Modifier
                .widthIn(min = 186.dp)
                .height(40.dp)
                .scale(launchScale)
                .testTag("launch_hero_game_button")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 24.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = ConsoleObsidian,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "LAUNCH GAME",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontSize = 13.sp,
                        letterSpacing = 0.9.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    color = ConsoleObsidian
                )
            }
        }
    }
}

@Composable
private fun EmptyHeroShowcase(onAddGame: () -> Unit) {
    val addInteraction = remember { MutableInteractionSource() }
    val addPressed by addInteraction.collectIsPressedAsState()
    val addScale by animateFloatAsState(
        targetValue = if (addPressed) 0.95f else 1f,
        animationSpec = tween(150),
        label = "empty_add_scale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(92.dp)
                .drawBehind {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(NeonGreen.copy(alpha = 0.22f), Color.Transparent),
                            center = Offset(size.width / 2f, size.height / 2f),
                            radius = size.minDimension * 0.68f
                        ),
                        radius = size.minDimension * 0.68f
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            SharkFinLogo(size = 54.dp)
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "SELECT OR ADD A GAME",
            style = MaterialTheme.typography.titleLarge.copy(letterSpacing = 1.sp),
            color = TextPrimary
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = "Add any installed game below to launch with your GREEN SHARK key-mapper",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary
        )

        Spacer(modifier = Modifier.height(14.dp))

        Surface(
            onClick = onAddGame,
            interactionSource = addInteraction,
            shape = CircleShape,
            color = NeonGreen,
            modifier = Modifier
                .height(40.dp)
                .scale(addScale)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 22.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = ConsoleObsidian, modifier = Modifier.size(18.dp))
                Text(
                    text = "ADD GAME",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontSize = 13.sp,
                        letterSpacing = 0.8.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    color = ConsoleObsidian
                )
            }
        }
    }
}

@Composable
private fun BottomFloatingGameDock(
    games: List<GameCardUi>,
    selectedPackage: String?,
    onSelectGame: (GameEntry) -> Unit,
    onLaunchGame: (GameEntry) -> Unit,
    onConfigureGame: (GameEntry) -> Unit,
    onAskRemoveGame: (GameEntry) -> Unit,
    onAddGameClick: () -> Unit
) {
    Surface(
        color = DockGlass,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, EmeraldGlassBorder),
        modifier = Modifier.widthIn(max = 760.dp)
    ) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 9.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(games, key = { it.entry.packageName }) { game ->
                DockGameItem(
                    game = game,
                    selected = game.entry.packageName == selectedPackage,
                    onSelect = { onSelectGame(game.entry) },
                    onLaunch = { onLaunchGame(game.entry) },
                    onConfigure = { onConfigureGame(game.entry) },
                    onRemove = { onAskRemoveGame(game.entry) }
                )
            }

            item(key = "add_game_dock_button") {
                DockAddGameButton(onClick = onAddGameClick)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DockGameItem(
    game: GameCardUi,
    selected: Boolean,
    onSelect: () -> Unit,
    onLaunch: () -> Unit,
    onConfigure: () -> Unit,
    onRemove: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = when {
            pressed -> 0.92f
            selected -> 1.06f
            else -> 1f
        },
        animationSpec = tween(150),
        label = "dock_item_scale"
    )

    Box {
        Surface(
            color = if (selected) NeonGreen.copy(alpha = 0.14f) else SurfaceElevated,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) NeonGreen else EmeraldGlassBorder
            ),
            modifier = Modifier
                .size(56.dp)
                .scale(scale)
                .clip(RoundedCornerShape(14.dp))
                .combinedClickable(
                    interactionSource = interactionSource,
                    indication = LocalIndication.current,
                    onClick = onSelect,
                    onLongClick = { menuExpanded = true }
                )
                .testTag("game_tile_${game.entry.packageName}")
        ) {
            Box(
                modifier = Modifier.fillMaxSize().padding(4.dp),
                contentAlignment = Alignment.Center
            ) {
                DrawableAppIcon(
                    drawable = game.icon,
                    contentDescription = game.entry.label,
                    modifier = Modifier.fillMaxSize(),
                    cornerRadius = 11.dp
                )
            }
        }

        DropdownMenu(
            expanded = menuExpanded,
            onDismissRequest = { menuExpanded = false },
            modifier = Modifier.background(SurfaceElevated)
        ) {
            DropdownMenuItem(
                text = { Text("Launch ${game.entry.label}", color = TextPrimary) },
                leadingIcon = { Icon(Icons.Default.PlayArrow, null, tint = NeonGreen) },
                onClick = {
                    menuExpanded = false
                    onLaunch()
                }
            )
            DropdownMenuItem(
                text = { Text("Edit Key-Map Preset", color = TextPrimary) },
                leadingIcon = { Icon(Icons.Default.Tune, null, tint = NeonGreen) },
                onClick = {
                    menuExpanded = false
                    onConfigure()
                }
            )
            DropdownMenuItem(
                text = { Text("Remove Game", color = DangerRed) },
                leadingIcon = { Icon(Icons.Default.Delete, null, tint = DangerRed) },
                onClick = {
                    menuExpanded = false
                    onRemove()
                }
            )
        }
    }
}

@Composable
private fun DockAddGameButton(onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.92f else 1f,
        animationSpec = tween(150),
        label = "dock_add_scale"
    )

    Box(
        modifier = Modifier
            .size(56.dp)
            .scale(scale)
            .clip(RoundedCornerShape(14.dp))
            .background(ConsoleObsidian.copy(alpha = 0.7f))
            .drawBehind {
                drawRoundRect(
                    color = NeonGreen.copy(alpha = 0.65f),
                    style = Stroke(
                        width = 1.2.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 7f), 0f)
                    ),
                    cornerRadius = CornerRadius(14.dp.toPx(), 14.dp.toPx())
                )
            }
            .clickable(
                interactionSource = interactionSource,
                indication = LocalIndication.current,
                onClick = onClick
            )
            .testTag("add_game_tile"),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Add,
            contentDescription = "Add Game",
            tint = NeonGreen,
            modifier = Modifier.size(24.dp)
        )
    }
}

@Composable
private fun TopBarIconButton(
    icon: ImageVector,
    contentDescription: String,
    tint: Color,
    onClick: () -> Unit,
    testTag: String
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.9f else 1f,
        animationSpec = tween(150),
        label = "topbar_btn_scale"
    )

    Surface(
        onClick = onClick,
        interactionSource = interactionSource,
        color = CardSurface,
        shape = CircleShape,
        border = BorderStroke(1.dp, EmeraldGlassBorder),
        modifier = Modifier
            .size(30.dp)
            .scale(scale)
            .testTag(testTag)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = tint,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
private fun CompactPeripheralBadge(
    icon: ImageVector,
    deviceLabel: String,
    connected: Boolean,
    testTag: String
) {
    val iconTint = if (connected) NeonGreen else TextMuted
    val borderColor = if (connected) NeonGreen.copy(alpha = 0.65f) else EmeraldGlassBorder
    val statusDescription = if (connected) "$deviceLabel connected" else "$deviceLabel disconnected"

    Box(
        modifier = Modifier
            .size(30.dp)
            .semantics { contentDescription = statusDescription }
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            color = if (connected) NeonGreen.copy(alpha = 0.14f) else CardSurface,
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, borderColor),
            modifier = Modifier
                .fillMaxSize()
                .drawBehind {
                    if (connected) {
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(NeonGreen.copy(alpha = 0.28f), Color.Transparent),
                                center = Offset(size.width / 2f, size.height / 2f),
                                radius = size.minDimension * 0.72f
                            ),
                            radius = size.minDimension * 0.72f
                        )
                    }
                }
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        if (!connected) {
            ProhibitedSlashBadge(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = 2.dp, y = 2.dp)
                    .size(11.dp)
            )
        }
    }
}

@Composable
private fun ProhibitedSlashBadge(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val r = size.minDimension / 2f
        val c = Offset(size.width / 2f, size.height / 2f)
        drawCircle(color = ConsoleObsidian, radius = r, center = c)

        val strokeW = (size.minDimension * 0.17f).coerceAtLeast(1.3f)
        val ringR = r - strokeW * 0.6f
        drawCircle(
            color = DangerRed,
            radius = ringR,
            center = c,
            style = Stroke(width = strokeW)
        )
        val diag = ringR * 0.68f
        drawLine(
            color = DangerRed,
            start = Offset(c.x - diag, c.y - diag),
            end = Offset(c.x + diag, c.y + diag),
            strokeWidth = strokeW,
            cap = StrokeCap.Round
        )
    }
}
