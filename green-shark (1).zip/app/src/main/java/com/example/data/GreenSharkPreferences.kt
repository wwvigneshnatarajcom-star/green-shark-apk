package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.ActivationMethod
import com.example.model.GameEntry
import com.example.model.GameMappingProfile
import com.example.model.GlobalSettings
import org.json.JSONArray

class GreenSharkPreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadAddedGames(): List<GameEntry> {
        val raw = prefs.getString(KEY_ADDED_GAMES, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    arr.optJSONObject(i)?.let { entry ->
                        val parsed = GameEntry.fromJson(entry)
                        if (parsed.packageName.isNotBlank()) add(parsed)
                    }
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveAddedGames(games: List<GameEntry>) {
        val arr = JSONArray().apply { games.forEach { put(it.toJson()) } }
        prefs.edit().putString(KEY_ADDED_GAMES, arr.toString()).apply()
    }

    fun loadGlobalSettings(): GlobalSettings =
        GlobalSettings.fromJsonString(prefs.getString(KEY_GLOBAL_SETTINGS, null))

    fun saveGlobalSettings(settings: GlobalSettings) {
        prefs.edit().putString(KEY_GLOBAL_SETTINGS, settings.toJson().toString()).apply()
    }

    fun loadProfile(packageName: String, fallbackLabel: String = "Default Pro"): GameMappingProfile {
        val raw = prefs.getString("$KEY_PROFILE_PREFIX$packageName", null)
        if (!raw.isNullOrBlank()) {
            GameMappingProfile.fromJsonString(raw, packageName)?.let { return it }
        }
        return GameMappingProfile.defaultFor(packageName, fallbackLabel)
    }

    fun saveProfile(profile: GameMappingProfile) {
        prefs.edit()
            .putString("$KEY_PROFILE_PREFIX${profile.packageName}", profile.toJson().toString())
            .apply()
    }

    fun resetProfile(packageName: String, label: String = "Default Pro"): GameMappingProfile {
        val fresh = GameMappingProfile.defaultFor(packageName, label)
        saveProfile(fresh)
        return fresh
    }

    fun loadActivationMethod(): ActivationMethod =
        ActivationMethod.fromName(prefs.getString(KEY_ACTIVATION_METHOD, null))

    fun saveActivationMethod(method: ActivationMethod) {
        prefs.edit().putString(KEY_ACTIVATION_METHOD, method.name).apply()
    }

    fun loadActiveGamePackage(): String =
        prefs.getString(KEY_ACTIVE_GAME_PKG, GLOBAL_FALLBACK_PKG) ?: GLOBAL_FALLBACK_PKG

    fun saveActiveGamePackage(packageName: String) {
        prefs.edit().putString(KEY_ACTIVE_GAME_PKG, packageName).apply()
    }

    fun loadLastWirelessPort(): String = prefs.getString(KEY_WIRELESS_PORT, "") ?: ""

    fun saveLastWirelessPort(port: String) {
        prefs.edit().putString(KEY_WIRELESS_PORT, port).apply()
    }

    companion object {
        private const val PREFS_NAME = "green_shark_prefs"
        private const val KEY_ADDED_GAMES = "added_games_json"
        private const val KEY_GLOBAL_SETTINGS = "global_settings_json"
        private const val KEY_PROFILE_PREFIX = "profile_"
        private const val KEY_ACTIVATION_METHOD = "activation_method"
        private const val KEY_ACTIVE_GAME_PKG = "active_game_pkg"
        private const val KEY_WIRELESS_PORT = "wireless_port"
        const val GLOBAL_FALLBACK_PKG = "com.greenshark.global"
    }
}
