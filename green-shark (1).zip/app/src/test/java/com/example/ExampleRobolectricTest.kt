package com.example

import android.content.Context
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.test.core.app.ApplicationProvider
import com.example.data.GreenSharkPreferences
import com.example.input.InputCaptureProcessor
import com.example.input.TouchInjectionEngine
import com.example.model.ActionMode
import com.example.model.GameEntry
import com.example.model.GameMappingProfile
import com.example.model.GlobalSettings
import com.example.model.KeyNode
import com.example.model.MacroSequence
import com.example.model.MacroStep
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name is GREEN SHARK`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("GREEN SHARK", appName)
    }

    @Test
    fun `profile json export and import round trip`() {
        val original = GameMappingProfile(
            packageName = "com.dts.freefireth",
            profileName = "Headshot Pro",
            keyNodes = listOf(
                KeyNode(
                    id = "k1",
                    keyCode = KeyEvent.KEYCODE_E,
                    keyLabel = "E",
                    xNorm = 0.72f,
                    yNorm = 0.65f,
                    actionMode = ActionMode.RAPID_FIRE,
                    rapidFireHz = 18
                )
            ),
            macros = listOf(
                MacroSequence(
                    id = "m1",
                    name = "Fast Gloo",
                    triggerKeyCode = KeyEvent.KEYCODE_Q,
                    triggerLabel = "Q",
                    steps = listOf(
                        MacroStep(id = "s1", stepNumber = 1, xNorm = 0.8f, yNorm = 0.8f, delayMs = 80L),
                        MacroStep(id = "s2", stepNumber = 2, xNorm = 0.85f, yNorm = 0.7f, delayMs = 110L)
                    )
                )
            )
        )

        val json = original.toJsonString()
        val parsed = GameMappingProfile.fromJsonString(json)
        assertNotNull(parsed)
        assertEquals("com.dts.freefireth", parsed?.packageName)
        assertEquals("Headshot Pro", parsed?.profileName)
        assertEquals(ActionMode.RAPID_FIRE, parsed?.keyNodes?.first()?.actionMode)
        assertEquals(2, parsed?.macros?.first()?.steps?.size)
        assertEquals(80L, parsed?.macros?.first()?.steps?.first()?.delayMs)
    }

    @Test
    fun `preferences persist games and settings`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = GreenSharkPreferences(context)
        val games = listOf(GameEntry("com.tencent.ig", "PUBG MOBILE", 1000L))
        prefs.saveAddedGames(games)
        assertEquals(1, prefs.loadAddedGames().size)
        assertEquals("PUBG MOBILE", prefs.loadAddedGames().first().label)

        val customSettings = GlobalSettings(xAxisSensitivity = 2.6f, keyOpacity = 0.55f)
        prefs.saveGlobalSettings(customSettings)
        val loaded = prefs.loadGlobalSettings()
        assertEquals(2.6f, loaded.xAxisSensitivity, 0.01f)
        assertEquals(0.55f, loaded.keyOpacity, 0.01f)
    }

    @Test
    fun `shooting mode toggle and WASD sprint vector update`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val engine = TouchInjectionEngine(context)
        val processor = InputCaptureProcessor(engine)
        val profile = GameMappingProfile.defaultFor("com.test.game")
        val settings = GlobalSettings()

        assertFalse(processor.runtimeState.value.shootingModeLocked)
        val toggleDown = KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_GRAVE)
        assertTrue(processor.handleKeyEvent(toggleDown, profile, settings))
        assertTrue(processor.runtimeState.value.shootingModeLocked)

        val wDown = KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_W)
        val shiftDown = KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_SHIFT_LEFT)
        processor.handleKeyEvent(wDown, profile, settings)
        processor.handleKeyEvent(shiftDown, profile, settings)

        assertTrue(processor.runtimeState.value.sprinting)
        assertTrue(processor.runtimeState.value.wasdVectorY < 0f)
    }

    @Test
    fun `node trigger pulse fires for wasd and mapped key`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val engine = TouchInjectionEngine(context)
        val processor = InputCaptureProcessor(engine)
        val profile = GameMappingProfile.defaultFor("com.test.game")
        val settings = GlobalSettings()

        val triggered = mutableListOf<String>()
        processor.onNodeTriggered = { triggered.add(it) }

        processor.handleKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_W), profile, settings)
        processor.handleKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_R), profile, settings)

        assertTrue("wasd" in triggered)
        assertTrue("default_reload" in triggered)
    }
}
